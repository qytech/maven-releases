# Native 组件与对应源码

qymultiroom 的 ARM64 解码器使用 FFmpeg 的 LGPL 构建，保留 TLS、DSD/DST 和 SACD 解析能力。解码器、缓存编解码和两个 Snapcast 程序分别使用组件自己的许可证。详见制品的 notices ZIP 和源码包内的版权文本。

每个正式版本在 qytech/maven-releases 的同版本 GitHub Release 提供完整的 Native 源码包。0.0.5 的入口为 [Native 对应源码与补丁](https://github.com/qytech/maven-releases/releases/download/qymultiroom-0.0.5/qymultiroom-0.0.5-native-sources.zip)。POM 指向该版本的下载地址，notices 内的 BUILD-INFO.json 记录源码包和五个 Native 文件的 SHA-256。

源码包带有 FFmpeg、OpenSSL、GNU libiconv、Boost 上游源码归档，实际使用的 SACD、Snapcast、soxr、FLAC、Opus 源码，QY 的 JNI 实现、接口、补丁、NDK 版本与构建说明。使用 Android NDK r28c 和 SDK CMake 3.22.1 解压后可运行：

```sh
ANDROID_HOME=/absolute/path/to/Android/sdk bash multi-room/native/rebuild_arm64.sh
```
