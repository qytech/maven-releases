# qymultiroom Native corresponding sources

This archive contains the ARM64 Native sources used for the qymultiroom Android SDK, including the QY modifications, the JNI interface declarations, build scripts, license texts and the exact upstream source archives. All Native source inputs needed after installing the build tools are included. The source archive for a Maven version is attached to the qytech/maven-releases GitHub release named qymultiroom-<version>. Its digest is recorded in the version's notices attachment.

## Rebuild on macOS or Linux

Install Python 3, Git, Bash, Perl, make, tar with gzip/bzip2 support, Android NDK 28.2.13676358 (r28c), and SDK CMake 3.22.1 with Ninja. Unzip into an empty directory. From the directory containing multi-room and upstream:

```sh
export ANDROID_HOME=/absolute/path/to/Android/sdk
bash multi-room/native/rebuild_arm64.sh
```

The five results are placed in build/native-output/arm64-v8a. Set JOBS to choose the parallelism. The four pinned source archives are verified by multi-room/native/source_inputs.py before extraction. The build scripts apply the Snapcast patch series in order to disposable source trees. The SACD parser snapshot already includes patches/parser.patch; its CMake transformation is applied at build time. The decoder CMake file also records the ARM64 soxr changes. Rebuild on the same host toolchain for binary comparisons; ELF build IDs, debug sections and compiler paths may differ across tools and build directories.

## Components and terms

- libmulti_room_decoder.so combines the QY JNI bridge, the SACD Ripper parser (GPL-2.0-or-later), FFmpeg commit 3e52cf113ed1fff47d39bab42f5254adb0819527 (LGPL-2.1-or-later configuration), OpenSSL 3.6.5 (Apache-2.0), GNU libiconv 1.16 and soxr (see their LGPL notices). The QY integration in this combined decoder is provided under GPL version 3. The SACD source snapshot is supplied in full as used by the decoder; the original import did not identify a specific upstream commit.
- libsnapclient.so and libsnapserver.so are patched Snapcast programs (GPL-3.0-or-later). The corresponding QY changes are provided under the same terms. Their source, all applied patches and the build files are included.
- libroomcodec.so uses the QY block codec and JNI bridge with Opus and FLAC. Its QY Native source is supplied for use, rebuilding and relinking with the SDK. Opus, libFLAC and Boost retain their own notices. Boost 1.85.0 headers are taken from the supplied upstream release.
- libc++_shared.so is copied unchanged from the Android NDK r28c ARM64 sysroot. The NDK notices, build manifest, LLVM base revision and Android patch references are in toolchain/. LLVM sources are at https://github.com/llvm/llvm-project/tree/3b5e7c83a6e226d5bd7ed2e9b67449b64812074c and the Android toolchain scripts and patch set are at https://android.googlesource.com/toolchain/llvm_android/+/e727bfb014bd436f581a66a450c939a6983a1fc3/.
- Each third-party component retains its authorship and license. The QY Native modifications in this distribution were prepared for the 0.0.5 release on 2026-11-21. License copies accompany the respective source trees and upstream archives.
