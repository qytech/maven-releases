# 独立音频编解码资产

qymultiroom 0.0.6 使用 FFmpeg n7.0.3-2-g3e52cf113e 的 LGPL-2.1-or-later 构建。目标为 Android ARM64 API 29，NDK 为 28.2.13676358。构建显式指定 `--disable-gpl --disable-nonfree --enable-openssl`。OpenSSL 3.6.5 使用 Apache-2.0，GNU libiconv 1.16 使用随上游提供的 LGPL 条款。

SACD Ripper 文件保留原作者声明和 GPL-2.0-or-later 许可。Android 解析器使用的完整快照、[修改记录](patches/parser.patch)、JNI 和 CMake 构建规则均随对应源码提供。QY 对组合解码器的 Native 集成在此分发中按 GPLv3 提供。Snapcast 修改及其他组件的说明见 [Native 分发说明](../../docs/sdk/THIRD_PARTY.md)。

[0.0.6 对应源码](https://github.com/qytech/maven-releases/releases/download/qymultiroom-0.0.6/qymultiroom-0.0.6-native-sources.zip) 包含原始上游归档和可离线重建的脚本。源包 SHA-256、链接后的五个库的 SHA-256 及 FFmpeg 配置见 [BUILD-INFO.json](BUILD-INFO.json)。
