# qymultiroom sources

This distribution does not include proprietary implementation sources.
Use the accompanying javadoc JAR and MULTI_ROOM_API.md for the public API.
The separate `-internal` version contains unobfuscated classes and sources for internal debugging only.

The versioned Native corresponding-source archive is linked from the POM. Its contents, component licenses and digest are described in the notices ZIP.

Maven Central permits a README-only sources attachment for closed-source artifacts:
https://central.sonatype.org/faq/closed-source/
