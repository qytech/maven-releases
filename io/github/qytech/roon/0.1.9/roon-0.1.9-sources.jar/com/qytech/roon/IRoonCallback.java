/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /opt/homebrew/share/android-commandlinetools/build-tools/36.0.0/aidl -p/opt/homebrew/share/android-commandlinetools/platforms/android-37.0/framework.aidl -o/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/build/generated/aidl_source_output_dir/debug/out -I/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/main/aidl -I/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/debug/aidl -I/Users/qytech/.gradle/caches/9.9.1/transforms/1eaa1a6e301040296efd58e0d436d4f2/transformed/core-1.19.0/aidl -I/Users/qytech/.gradle/caches/9.9.1/transforms/199833c827f01384da423ca795a8db7c/transformed/versionedparcelable-1.1.1/aidl -d/var/folders/8_/p7gp5n2d41j5hzmnhnxgsqkm0000gn/T/aidl3317512609731944.d /Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/main/aidl/com/qytech/roon/IRoonCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package com.qytech.roon;
public interface IRoonCallback extends android.os.IInterface
{
  /** Default implementation for IRoonCallback. */
  public static class Default implements com.qytech.roon.IRoonCallback
  {
    @Override public void onPlayStateChanged(com.qytech.roon.model.RoonPlayState state) throws android.os.RemoteException
    {
    }
    @Override public void onMetadataChanged(com.qytech.roon.model.RoonMetadata metadata) throws android.os.RemoteException
    {
    }
    @Override public void onVolumeStateChanged(com.qytech.roon.model.VolumeState volume) throws android.os.RemoteException
    {
    }
    @Override public void onArtworkChanged(java.lang.String mimeType, byte[] data) throws android.os.RemoteException
    {
    }
    @Override public void onStreamFormatChanged(com.qytech.roon.model.StreamFormat format) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.qytech.roon.IRoonCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.qytech.roon.IRoonCallback interface,
     * generating a proxy if needed.
     */
    public static com.qytech.roon.IRoonCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.qytech.roon.IRoonCallback))) {
        return ((com.qytech.roon.IRoonCallback)iin);
      }
      return new com.qytech.roon.IRoonCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onPlayStateChanged:
        {
          com.qytech.roon.model.RoonPlayState _arg0;
          _arg0 = _Parcel.readTypedObject(data, com.qytech.roon.model.RoonPlayState.CREATOR);
          this.onPlayStateChanged(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_onMetadataChanged:
        {
          com.qytech.roon.model.RoonMetadata _arg0;
          _arg0 = _Parcel.readTypedObject(data, com.qytech.roon.model.RoonMetadata.CREATOR);
          this.onMetadataChanged(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_onVolumeStateChanged:
        {
          com.qytech.roon.model.VolumeState _arg0;
          _arg0 = _Parcel.readTypedObject(data, com.qytech.roon.model.VolumeState.CREATOR);
          this.onVolumeStateChanged(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_onArtworkChanged:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          byte[] _arg1;
          _arg1 = data.createByteArray();
          this.onArtworkChanged(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_onStreamFormatChanged:
        {
          com.qytech.roon.model.StreamFormat _arg0;
          _arg0 = _Parcel.readTypedObject(data, com.qytech.roon.model.StreamFormat.CREATOR);
          this.onStreamFormatChanged(_arg0);
          reply.writeNoException();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.qytech.roon.IRoonCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void onPlayStateChanged(com.qytech.roon.model.RoonPlayState state) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, state, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onPlayStateChanged, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void onMetadataChanged(com.qytech.roon.model.RoonMetadata metadata) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, metadata, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onMetadataChanged, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void onVolumeStateChanged(com.qytech.roon.model.VolumeState volume) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, volume, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onVolumeStateChanged, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void onArtworkChanged(java.lang.String mimeType, byte[] data) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(mimeType);
          _data.writeByteArray(data);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onArtworkChanged, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void onStreamFormatChanged(com.qytech.roon.model.StreamFormat format) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, format, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onStreamFormatChanged, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onPlayStateChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_onMetadataChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_onVolumeStateChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_onArtworkChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_onStreamFormatChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.qytech.roon.IRoonCallback";
  public void onPlayStateChanged(com.qytech.roon.model.RoonPlayState state) throws android.os.RemoteException;
  public void onMetadataChanged(com.qytech.roon.model.RoonMetadata metadata) throws android.os.RemoteException;
  public void onVolumeStateChanged(com.qytech.roon.model.VolumeState volume) throws android.os.RemoteException;
  public void onArtworkChanged(java.lang.String mimeType, byte[] data) throws android.os.RemoteException;
  public void onStreamFormatChanged(com.qytech.roon.model.StreamFormat format) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
