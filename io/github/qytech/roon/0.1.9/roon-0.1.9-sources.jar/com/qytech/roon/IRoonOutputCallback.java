/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /opt/homebrew/share/android-commandlinetools/build-tools/36.0.0/aidl -p/opt/homebrew/share/android-commandlinetools/platforms/android-37.0/framework.aidl -o/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/build/generated/aidl_source_output_dir/debug/out -I/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/main/aidl -I/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/debug/aidl -I/Users/qytech/.gradle/caches/9.9.1/transforms/1eaa1a6e301040296efd58e0d436d4f2/transformed/core-1.19.0/aidl -I/Users/qytech/.gradle/caches/9.9.1/transforms/199833c827f01384da423ca795a8db7c/transformed/versionedparcelable-1.1.1/aidl -d/var/folders/8_/p7gp5n2d41j5hzmnhnxgsqkm0000gn/T/aidl10324898781574575524.d /Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/main/aidl/com/qytech/roon/IRoonOutputCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package com.qytech.roon;
/** Requests release of the previous output owner before Roon opens an AudioTrack. */
public interface IRoonOutputCallback extends android.os.IInterface
{
  /** Default implementation for IRoonOutputCallback. */
  public static class Default implements com.qytech.roon.IRoonOutputCallback
  {
    @Override public void onPreparePlaybackOutput(com.qytech.roon.IRoonOutputPreparation request) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.qytech.roon.IRoonOutputCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.qytech.roon.IRoonOutputCallback interface,
     * generating a proxy if needed.
     */
    public static com.qytech.roon.IRoonOutputCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.qytech.roon.IRoonOutputCallback))) {
        return ((com.qytech.roon.IRoonOutputCallback)iin);
      }
      return new com.qytech.roon.IRoonOutputCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onPreparePlaybackOutput:
        {
          com.qytech.roon.IRoonOutputPreparation _arg0;
          _arg0 = com.qytech.roon.IRoonOutputPreparation.Stub.asInterface(data.readStrongBinder());
          this.onPreparePlaybackOutput(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.qytech.roon.IRoonOutputCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void onPreparePlaybackOutput(com.qytech.roon.IRoonOutputPreparation request) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(request);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onPreparePlaybackOutput, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onPreparePlaybackOutput = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.qytech.roon.IRoonOutputCallback";
  public void onPreparePlaybackOutput(com.qytech.roon.IRoonOutputPreparation request) throws android.os.RemoteException;
}
