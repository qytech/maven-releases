/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /opt/homebrew/share/android-commandlinetools/build-tools/36.0.0/aidl -p/opt/homebrew/share/android-commandlinetools/platforms/android-37.0/framework.aidl -o/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/build/generated/aidl_source_output_dir/debug/out -I/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/main/aidl -I/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/debug/aidl -I/Users/qytech/.gradle/caches/9.9.1/transforms/1eaa1a6e301040296efd58e0d436d4f2/transformed/core-1.19.0/aidl -I/Users/qytech/.gradle/caches/9.9.1/transforms/199833c827f01384da423ca795a8db7c/transformed/versionedparcelable-1.1.1/aidl -d/var/folders/8_/p7gp5n2d41j5hzmnhnxgsqkm0000gn/T/aidl1462415853904525797.d /Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/main/aidl/com/qytech/roon/IRoonOutputPreparation.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package com.qytech.roon;
/** A single setup request; expired requests must not change the host's output owner. */
public interface IRoonOutputPreparation extends android.os.IInterface
{
  /** Default implementation for IRoonOutputPreparation. */
  public static class Default implements com.qytech.roon.IRoonOutputPreparation
  {
    @Override public boolean isCurrent() throws android.os.RemoteException
    {
      return false;
    }
    @Override public void complete(boolean ready) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.qytech.roon.IRoonOutputPreparation
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.qytech.roon.IRoonOutputPreparation interface,
     * generating a proxy if needed.
     */
    public static com.qytech.roon.IRoonOutputPreparation asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.qytech.roon.IRoonOutputPreparation))) {
        return ((com.qytech.roon.IRoonOutputPreparation)iin);
      }
      return new com.qytech.roon.IRoonOutputPreparation.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_isCurrent:
        {
          boolean _result = this.isCurrent();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_complete:
        {
          boolean _arg0;
          _arg0 = (0!=data.readInt());
          this.complete(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.qytech.roon.IRoonOutputPreparation
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public boolean isCurrent() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_isCurrent, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void complete(boolean ready) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(((ready)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_complete, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_isCurrent = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_complete = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.qytech.roon.IRoonOutputPreparation";
  public boolean isCurrent() throws android.os.RemoteException;
  public void complete(boolean ready) throws android.os.RemoteException;
}
