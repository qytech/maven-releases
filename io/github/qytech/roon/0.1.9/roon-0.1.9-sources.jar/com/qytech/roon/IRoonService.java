/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /opt/homebrew/share/android-commandlinetools/build-tools/36.0.0/aidl -p/opt/homebrew/share/android-commandlinetools/platforms/android-37.0/framework.aidl -o/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/build/generated/aidl_source_output_dir/debug/out -I/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/main/aidl -I/Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/debug/aidl -I/Users/qytech/.gradle/caches/9.9.1/transforms/1eaa1a6e301040296efd58e0d436d4f2/transformed/core-1.19.0/aidl -I/Users/qytech/.gradle/caches/9.9.1/transforms/199833c827f01384da423ca795a8db7c/transformed/versionedparcelable-1.1.1/aidl -d/var/folders/8_/p7gp5n2d41j5hzmnhnxgsqkm0000gn/T/aidl12148904402709964014.d /Users/qytech/workspace/repos/QYHifiPlayer/drivers/connect/roon/src/main/aidl/com/qytech/roon/IRoonService.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package com.qytech.roon;
public interface IRoonService extends android.os.IInterface
{
  /** Default implementation for IRoonService. */
  public static class Default implements com.qytech.roon.IRoonService
  {
    @Override public void startRoon(java.lang.String name, java.lang.String uuid, java.lang.String serial, java.lang.String version, java.lang.String model, java.lang.String vendor, int maxDsdRate, java.util.List<com.qytech.roon.model.SupportedFormat> supportedFormats, java.util.List<com.qytech.roon.model.SignalPath> signalPaths) throws android.os.RemoteException
    {
    }
    @Override public void stopRoon() throws android.os.RemoteException
    {
    }
    @Override public void next() throws android.os.RemoteException
    {
    }
    @Override public void previous() throws android.os.RemoteException
    {
    }
    @Override public void pause() throws android.os.RemoteException
    {
    }
    @Override public void play() throws android.os.RemoteException
    {
    }
    @Override public void playPause() throws android.os.RemoteException
    {
    }
    @Override public void seek(int position) throws android.os.RemoteException
    {
    }
    @Override public void toggleLoop() throws android.os.RemoteException
    {
    }
    @Override public void toggleShuffle() throws android.os.RemoteException
    {
    }
    @Override public void registerCallback(com.qytech.roon.IRoonCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void unregisterCallback(com.qytech.roon.IRoonCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void registerPlaybackController(com.qytech.roon.IRoonPlaybackController controller) throws android.os.RemoteException
    {
    }
    @Override public void unregisterPlaybackController(com.qytech.roon.IRoonPlaybackController controller) throws android.os.RemoteException
    {
    }
    @Override public void reportVolumeState(double volume, boolean muted) throws android.os.RemoteException
    {
    }
    @Override public void updateSignalPath(com.qytech.roon.model.SignalPath signalPath) throws android.os.RemoteException
    {
    }
    @Override public boolean releasePlaybackOutput() throws android.os.RemoteException
    {
      return false;
    }
    @Override public void registerOutputCallback(com.qytech.roon.IRoonOutputCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void unregisterOutputCallback(com.qytech.roon.IRoonOutputCallback callback) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.qytech.roon.IRoonService
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.qytech.roon.IRoonService interface,
     * generating a proxy if needed.
     */
    public static com.qytech.roon.IRoonService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.qytech.roon.IRoonService))) {
        return ((com.qytech.roon.IRoonService)iin);
      }
      return new com.qytech.roon.IRoonService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_startRoon:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _arg1;
          _arg1 = data.readString();
          java.lang.String _arg2;
          _arg2 = data.readString();
          java.lang.String _arg3;
          _arg3 = data.readString();
          java.lang.String _arg4;
          _arg4 = data.readString();
          java.lang.String _arg5;
          _arg5 = data.readString();
          int _arg6;
          _arg6 = data.readInt();
          java.util.List<com.qytech.roon.model.SupportedFormat> _arg7;
          _arg7 = data.createTypedArrayList(com.qytech.roon.model.SupportedFormat.CREATOR);
          java.util.List<com.qytech.roon.model.SignalPath> _arg8;
          _arg8 = data.createTypedArrayList(com.qytech.roon.model.SignalPath.CREATOR);
          this.startRoon(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7, _arg8);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_stopRoon:
        {
          this.stopRoon();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_next:
        {
          this.next();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_previous:
        {
          this.previous();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_pause:
        {
          this.pause();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_play:
        {
          this.play();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_playPause:
        {
          this.playPause();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_seek:
        {
          int _arg0;
          _arg0 = data.readInt();
          this.seek(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_toggleLoop:
        {
          this.toggleLoop();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_toggleShuffle:
        {
          this.toggleShuffle();
          reply.writeNoException();
          break;
        }
        case TRANSACTION_registerCallback:
        {
          com.qytech.roon.IRoonCallback _arg0;
          _arg0 = com.qytech.roon.IRoonCallback.Stub.asInterface(data.readStrongBinder());
          this.registerCallback(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_unregisterCallback:
        {
          com.qytech.roon.IRoonCallback _arg0;
          _arg0 = com.qytech.roon.IRoonCallback.Stub.asInterface(data.readStrongBinder());
          this.unregisterCallback(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_registerPlaybackController:
        {
          com.qytech.roon.IRoonPlaybackController _arg0;
          _arg0 = com.qytech.roon.IRoonPlaybackController.Stub.asInterface(data.readStrongBinder());
          this.registerPlaybackController(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_unregisterPlaybackController:
        {
          com.qytech.roon.IRoonPlaybackController _arg0;
          _arg0 = com.qytech.roon.IRoonPlaybackController.Stub.asInterface(data.readStrongBinder());
          this.unregisterPlaybackController(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_reportVolumeState:
        {
          double _arg0;
          _arg0 = data.readDouble();
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          this.reportVolumeState(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_updateSignalPath:
        {
          com.qytech.roon.model.SignalPath _arg0;
          _arg0 = _Parcel.readTypedObject(data, com.qytech.roon.model.SignalPath.CREATOR);
          this.updateSignalPath(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_releasePlaybackOutput:
        {
          boolean _result = this.releasePlaybackOutput();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        case TRANSACTION_registerOutputCallback:
        {
          com.qytech.roon.IRoonOutputCallback _arg0;
          _arg0 = com.qytech.roon.IRoonOutputCallback.Stub.asInterface(data.readStrongBinder());
          this.registerOutputCallback(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_unregisterOutputCallback:
        {
          com.qytech.roon.IRoonOutputCallback _arg0;
          _arg0 = com.qytech.roon.IRoonOutputCallback.Stub.asInterface(data.readStrongBinder());
          this.unregisterOutputCallback(_arg0);
          reply.writeNoException();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.qytech.roon.IRoonService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void startRoon(java.lang.String name, java.lang.String uuid, java.lang.String serial, java.lang.String version, java.lang.String model, java.lang.String vendor, int maxDsdRate, java.util.List<com.qytech.roon.model.SupportedFormat> supportedFormats, java.util.List<com.qytech.roon.model.SignalPath> signalPaths) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(name);
          _data.writeString(uuid);
          _data.writeString(serial);
          _data.writeString(version);
          _data.writeString(model);
          _data.writeString(vendor);
          _data.writeInt(maxDsdRate);
          _Parcel.writeTypedList(_data, supportedFormats, 0);
          _Parcel.writeTypedList(_data, signalPaths, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_startRoon, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void stopRoon() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_stopRoon, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void next() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_next, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void previous() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_previous, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void pause() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_pause, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void play() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_play, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void playPause() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_playPause, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void seek(int position) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeInt(position);
          boolean _status = mRemote.transact(Stub.TRANSACTION_seek, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void toggleLoop() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_toggleLoop, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void toggleShuffle() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_toggleShuffle, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void registerCallback(com.qytech.roon.IRoonCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerCallback, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void unregisterCallback(com.qytech.roon.IRoonCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_unregisterCallback, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void registerPlaybackController(com.qytech.roon.IRoonPlaybackController controller) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(controller);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerPlaybackController, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void unregisterPlaybackController(com.qytech.roon.IRoonPlaybackController controller) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(controller);
          boolean _status = mRemote.transact(Stub.TRANSACTION_unregisterPlaybackController, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void reportVolumeState(double volume, boolean muted) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeDouble(volume);
          _data.writeInt(((muted)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_reportVolumeState, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void updateSignalPath(com.qytech.roon.model.SignalPath signalPath) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, signalPath, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateSignalPath, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public boolean releasePlaybackOutput() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_releasePlaybackOutput, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void registerOutputCallback(com.qytech.roon.IRoonOutputCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerOutputCallback, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void unregisterOutputCallback(com.qytech.roon.IRoonOutputCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_unregisterOutputCallback, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_startRoon = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_stopRoon = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_next = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_previous = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_pause = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_play = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_playPause = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_seek = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_toggleLoop = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_toggleShuffle = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
    static final int TRANSACTION_registerCallback = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
    static final int TRANSACTION_unregisterCallback = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
    static final int TRANSACTION_registerPlaybackController = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
    static final int TRANSACTION_unregisterPlaybackController = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
    static final int TRANSACTION_reportVolumeState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
    static final int TRANSACTION_updateSignalPath = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
    static final int TRANSACTION_releasePlaybackOutput = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
    static final int TRANSACTION_registerOutputCallback = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
    static final int TRANSACTION_unregisterOutputCallback = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.qytech.roon.IRoonService";
  public void startRoon(java.lang.String name, java.lang.String uuid, java.lang.String serial, java.lang.String version, java.lang.String model, java.lang.String vendor, int maxDsdRate, java.util.List<com.qytech.roon.model.SupportedFormat> supportedFormats, java.util.List<com.qytech.roon.model.SignalPath> signalPaths) throws android.os.RemoteException;
  public void stopRoon() throws android.os.RemoteException;
  public void next() throws android.os.RemoteException;
  public void previous() throws android.os.RemoteException;
  public void pause() throws android.os.RemoteException;
  public void play() throws android.os.RemoteException;
  public void playPause() throws android.os.RemoteException;
  public void seek(int position) throws android.os.RemoteException;
  public void toggleLoop() throws android.os.RemoteException;
  public void toggleShuffle() throws android.os.RemoteException;
  public void registerCallback(com.qytech.roon.IRoonCallback callback) throws android.os.RemoteException;
  public void unregisterCallback(com.qytech.roon.IRoonCallback callback) throws android.os.RemoteException;
  public void registerPlaybackController(com.qytech.roon.IRoonPlaybackController controller) throws android.os.RemoteException;
  public void unregisterPlaybackController(com.qytech.roon.IRoonPlaybackController controller) throws android.os.RemoteException;
  public void reportVolumeState(double volume, boolean muted) throws android.os.RemoteException;
  public void updateSignalPath(com.qytech.roon.model.SignalPath signalPath) throws android.os.RemoteException;
  public boolean releasePlaybackOutput() throws android.os.RemoteException;
  public void registerOutputCallback(com.qytech.roon.IRoonOutputCallback callback) throws android.os.RemoteException;
  public void unregisterOutputCallback(com.qytech.roon.IRoonOutputCallback callback) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedList(
        android.os.Parcel parcel, java.util.List<T> value, int parcelableFlags) {
      if (value == null) {
        parcel.writeInt(-1);
      } else {
        int N = value.size();
        int i = 0;
        parcel.writeInt(N);
        while (i < N) {
    writeTypedObject(parcel, value.get(i), parcelableFlags);
          i++;
        }
      }
    }
  }
}
