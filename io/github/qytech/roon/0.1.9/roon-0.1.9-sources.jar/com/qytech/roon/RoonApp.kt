package com.qytech.roon

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.AudioTimestamp
import android.os.Build
import com.google.gson.Gson
import com.qytech.audioplayer.audioframe.DsdResampler
import com.qytech.audioplayer.utils.SystemPropUtil
import com.qytech.roon.model.RoonMetadata
import com.qytech.roon.model.RoonPlayState
import com.qytech.roon.model.SignalPath
import com.qytech.roon.model.StreamFormat
import com.qytech.roon.model.SupportedFormat
import com.qytech.roon.model.VolumeState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asExecutor
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.newFixedThreadPoolContext
import timber.log.Timber
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit

/** Queue behind native startup and suppress only the dummy plugin's synchronous local echo. */
internal fun CoroutineScope.launchLocalVolumeReport(
    reportingLocalVolume: ThreadLocal<Boolean>,
    report: () -> Unit,
): Job = launch {
    reportingLocalVolume.set(true)
    try {
        runCatching(report).onFailure { Timber.w(it, "Failed to report Roon volume") }
    } finally {
        reportingLocalVolume.remove()
    }
}

@SuppressLint("InlinedApi")
class RoonApp {
    companion object {
        init {
            System.loadLibrary("roon")
        }
    }

    private val gson = Gson()
    private var started = false
    // Control operations may interrupt write(), but cannot release a track still held by a writer.
    private val audioTrackControlLock = Any()
    private val outputTakeoverLock = Any()
    @Volatile private var outputAllowed = true
    private var outputTakeoverInProgress = false
    private var outputSetupStopped = false
    private val audioTrackStateLock = Any()
    private var audioTrackState: AudioTrackState? = null
    private val pendingTrackReleases = mutableListOf<RoonOutputRelease>()
    private val audioTrack: AudioTrack?
        get() = audioTrackState?.track
    private var currentStreamFormat: StreamFormat? = null
    private var jniCallBack = RaatJniCallBackImpl()
    private var isJniCallBackRegistered = false
    private val remoteCallbacks = RoonCallbackConnection(Dispatchers.IO.asExecutor())
    private val deadTrackRecoveryPolicy = RoonDeadTrackRecoveryPolicy()
    private val outputHandshake = RoonOutputHandshake(
        lock = audioTrackControlLock,
        isSetupAllowed = { !outputSetupStopped && !outputTakeoverInProgress },
        onBegin = {
            deadTrackRecoveryPolicy.reset()
            synchronized(audioTrackStateLock) { clockEpochNs = 0L }
            outputAllowed = false
        },
    )
    private var playbackController: IRoonPlaybackController? = null
    private val reportingLocalVolume = ThreadLocal<Boolean>()

    // -----------------------------------------------------------
    // 零拷贝优化：使用 DirectByteBuffer 替代 ByteArray
    // DirectBuffer 的内存分配在 Native 堆上，JNI 访问时无需拷贝
    // -----------------------------------------------------------
    private var directInputBuffer: ByteBuffer? = null
    private var directOutputBuffer: ByteBuffer? = null

    private var dsdResampler: DsdResampler? = null

    @OptIn(DelicateCoroutinesApi::class)
    private val coroutineScope = CoroutineScope(newFixedThreadPoolContext(1, "RaatApp"))

    private var roonJob: Job? = null
    private var isD2PFallback = false

    // 当前是否处于播放态。MQA 检出后 native 会以解码格式(2×/32bit)重新上报一次
    // onStreamFormatChanged，此时 AudioTrack 会被重建；若此前已在播放，需让新 track
    // 立即 play()（正常首次流程中 format 早于 play，flag 为 false 不会误启动）。
    private var playing = false
    private var sinkActive = false
    private var clockEpochNs = 0L

    private class AudioTrackState(
        val track: AudioTrack,
        val format: StreamFormat?,
        val d2pFallback: Boolean,
        epochNs: Long,
        startupFrames: Int,
        i2sFourChannel: Boolean = false,
    ) {
        val effectiveClockRate: Int = if (
            format?.isDsd() == true &&
            !d2pFallback &&
            (i2sFourChannel || track.channelCount == 4)
        ) {
            track.sampleRate / 2
        } else {
            track.sampleRate
        }
        val clock = RoonPresentationClock(effectiveClockRate, epochNs, startupFrames)
        val timestamp = AudioTimestamp()
        val bytesPerFrame = track.channelCount * when (track.audioFormat) {
            AudioFormat.ENCODING_PCM_8BIT -> 1
            AudioFormat.ENCODING_PCM_16BIT -> 2
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> 3
            else -> 4
        }
        var lastClockLogNs = 0L
        var writers = 0
        var clockReaders = 0
        var retired = false
        var dead = false
        var stopCompleted = false
        var released = false
        val releaseCompletion = RoonOutputRelease()
    }

    // 是否强制使用 DoP 模式 (如果你的业务逻辑需要支持 DoP，可以通过外部设置此变量)
    var isDoPEnabled = false

    // I2S 4 声道输出：部分 I2S 硬件需要把立体声 DSD 重排为 4 声道布局再输出。
    // 由系统属性 persist.sys.audio.i2s 控制(=1/true 启用)，只读一次。
    // 仅作用于原生 DSD 直通路径(D2P 软解回退仍按立体声 PCM 输出)。
    private val i2sFourChannel: Boolean by lazy {
        SystemPropUtil.getBoolean("persist.sys.audio.i2s", false)
    }

    /** Replaces the host status subscription; re-register after a failed Binder connection. */
    fun registerCallback(callback: IRoonCallback) {
        remoteCallbacks.register(callback)
    }

    /** Registers the host's asynchronous output-release acknowledgement. */
    fun registerOutputCallback(callback: IRoonOutputCallback) {
        outputHandshake.register(callback)
    }

    /** Removes the output owner callback when its host disconnects. */
    fun unregisterOutputCallback(callback: IRoonOutputCallback) {
        synchronized(audioTrackControlLock) {
            if (outputHandshake.unregister(callback)) outputAllowed = false
        }
    }

    /** Detaches only the subscription belonging to this callback's underlying Binder. */
    fun unregisterCallback(callback: IRoonCallback) {
        remoteCallbacks.unregister(callback)
    }

    fun registerPlaybackController(playbackController: IRoonPlaybackController) {
        this.playbackController = playbackController
    }

    fun unregisterPlaybackController(playbackController: IRoonPlaybackController) {
        if (this.playbackController == playbackController) {
            this.playbackController = null
        }
    }

    init {
        init()
    }

    fun init() {
        if (isJniCallBackRegistered) {
            return
        }
        registerJniCallback(jniCallBack)
        synchronized(audioTrackControlLock) { outputSetupStopped = false }
        isJniCallBackRegistered = true
    }

    fun release() {
        remoteCallbacks.clear()
        synchronized(audioTrackControlLock) {
            outputSetupStopped = true
            outputHandshake.clear()
            outputAllowed = false
            synchronized(audioTrackStateLock) { playing = false; sinkActive = false }
            releaseAudioTrack()
            currentStreamFormat = null
        }
        isJniCallBackRegistered = false
        unregisterJniCallback()
    }

    @Synchronized
    fun start(
        context: Context,
        name: String,
        uuid: String,
        serial: String,
        version: String,
        model: String = Build.MODEL,
        vendor: String = Build.MANUFACTURER,
        maxDsdRate: Int = 512,
        supportedFormats: List<SupportedFormat> = emptyList(),
        signalPaths: List<SignalPath> = emptyList(),
    ) = runCatching {
        if (started) {
            Timber.d("already started")
            return@runCatching
        }
        synchronized(audioTrackControlLock) { outputSetupStopped = false }
        roonJob = coroutineScope.launch {
            raatStart(
                name,
                uuid,
                serial,
                version,
                model,
                vendor,
                maxDsdRate,
                supportedFormats,
                signalPaths
            )
        }
        started = true
    }

    @Synchronized
    fun stop() = runCatching {
        synchronized(audioTrackControlLock) {
            outputSetupStopped = true
            cancelOutputPreparation()
            outputAllowed = false
            synchronized(audioTrackStateLock) { playing = false; sinkActive = false }
            releaseAudioTrack()
            currentStreamFormat = null
        }
        if (!started) return@runCatching
        coroutineScope.launch { raatStop() }
        roonJob?.cancel()
        started = false
    }

    /** Releases the sink on the existing control queue before retiring the isolated SDK process. */
    internal fun retireProcess(lifetime: RoonProcessLifetime, terminate: () -> Unit) {
        lifetime.retire(
            enqueue = { task -> coroutineScope.launch { task() } },
            releaseOutput = {
                remoteCallbacks.clear()
                synchronized(audioTrackControlLock) {
                    outputSetupStopped = true
                    outputHandshake.clear()
                }
                releasePlaybackOutput(retiring = true)
            },
            terminate = terminate,
        )
    }

    @Synchronized
    fun updateSignalPath(signalPath: SignalPath) {
        if (!started) return
        coroutineScope.launch {
            raatUpdateSignalPath(signalPath.quality, signalPath.type, signalPath.method)
        }
    }

    fun next() = raatNext()
    fun previous() = raatPrevious()
    fun pause() = raatPause()

    /** Releases this output for another source; ordinary pause keeps its prefill buffer. Call off main. */
    fun releasePlaybackOutput(): Boolean = releasePlaybackOutput(retiring = false)

    private fun releasePlaybackOutput(retiring: Boolean): Boolean = synchronized(outputTakeoverLock) {
        synchronized(audioTrackControlLock) {
            outputTakeoverInProgress = true
            cancelOutputPreparation()
            outputAllowed = false
            deadTrackRecoveryPolicy.reset()
            synchronized(audioTrackStateLock) {
                playing = false
                sinkActive = false
            }
            releaseAudioTrack()
            currentStreamFormat = null
        }
        try {
            // Native joins the writer; a sampler may still retain this or an older track.
            // Neither join nor completion waits may hold the control/state locks.
            val nativeReleased = raatReleasePlaybackOutput(retiring)
            val releases = synchronized(audioTrackStateLock) { pendingTrackReleases.toList() }
            val tracksReleased = awaitRoonOutputReleases(releases, TimeUnit.SECONDS.toNanos(5))
            synchronized(audioTrackStateLock) { pendingTrackReleases.removeAll { it.succeeded } }
            nativeReleased && tracksReleased
        } finally {
            synchronized(audioTrackControlLock) { outputTakeoverInProgress = false }
        }
    }
    fun play() = raatPlay()
    fun playPause() = raatPlayPause()
    fun seek(position: Int) = raatSeek(position)
    fun toggleLoop() = raatToggleLoop()
    fun toggleShuffle() = raatToggleShuffle()
    @Synchronized
    fun reportVolume(volume: Double, muted: Boolean) {
        if (!started) return
        Timber.d("[Volume E3] RoonApp.reportVolume: volume=$volume muted=$muted")
        coroutineScope.launchLocalVolumeReport(reportingLocalVolume) {
            raatReportVolume(volume, muted)
        }
    }

    private external fun registerJniCallback(callback: RaatJniBridgeCallback)
    private external fun unregisterJniCallback()
    private external fun raatStart(
        name: String,
        uuid: String,
        serial: String,
        version: String,
        model: String,
        vendor: String,
        maxDsdRate: Int,
        supportedFormats: List<SupportedFormat>,
        signalPaths: List<SignalPath>
    )

    private external fun raatStop()
    private external fun raatUpdateSignalPath(quality: String, type: String, method: String)
    private external fun raatNext()
    private external fun raatPrevious()
    private external fun raatPause()
    private external fun raatReleasePlaybackOutput(retiring: Boolean): Boolean
    private external fun raatPlay()
    private external fun raatPlayPause()
    private external fun raatSeek(position: Int)
    private external fun raatToggleLoop()
    private external fun raatToggleShuffle()
    private external fun raatReportVolume(volume: Double, muted: Boolean)

    /**
     * 辅助函数：确保 DirectByteBuffer 容量足够
     * 如果容量不足，重新分配一个更大的 DirectBuffer
     */
    private fun ensureBufferCapacity(buffer: ByteBuffer?, neededSize: Int): ByteBuffer {
        if (buffer == null || buffer.capacity() < neededSize) {
            // 分配新的 Direct Memory，容量稍微给大一点以免频繁扩容
            return ByteBuffer.allocateDirect(neededSize).apply {
                order(ByteOrder.LITTLE_ENDIAN) // 保持字节序习惯
            }
        }
        buffer.clear() // 重置指针
        return buffer
    }

    // Called with the control lock held, before any native operation that can wait for setup.
    private fun cancelOutputPreparation() {
        outputHandshake.cancel()
    }

    private inner class RaatJniCallBackImpl : RaatJniBridgeCallback {
        override fun onOutputSetup(): Boolean {
            return outputHandshake.prepare(
                onReady = { outputAllowed = true },
                send = { owner, request ->
                    owner.onPreparePlaybackOutput(object : IRoonOutputPreparation.Stub() {
                        override fun isCurrent(): Boolean = request.isCurrent()
                        override fun complete(ready: Boolean) = request.complete(ready)
                    })
                },
            )
        }

        override fun onOutputClock(): LongArray? = synchronized(audioTrackStateLock) {
            // The legacy external-controller contract has no presentation-position API.
            if (playbackController != null) return@synchronized longArrayOf(-1L, -1L)
            val state = audioTrackState ?: return@synchronized null
            if (!outputAllowed || state.retired || state.released) return@synchronized null
            val played = state.clock.positionNs(System.nanoTime()) ?: return@synchronized null
            longArrayOf(played, state.clock.writtenNs())
        }

        override fun onVolumeStateChanged(volumeState: VolumeState) {
            if (reportingLocalVolume.get() == true) return
            remoteCallbacks.dispatch(RoonCallbackConnection.Kind.VOLUME) { it.onVolumeStateChanged(volumeState) }
        }

        override fun onAudioDataChanged(data: ByteArray, size: Int) {
            if (!outputAllowed) return
            if (playbackController != null) {
                playbackController?.onAudioDataReceived(data, size)
                return
            }

            val state = synchronized(audioTrackStateLock) {
                if (!outputAllowed) return
                (audioTrackState ?: return).also { it.writers++ }
            }
            try {
                writeAudioData(state, data, size)
            } finally {
                synchronized(audioTrackStateLock) { state.writers-- }
                releaseRetiredAudioTrack(state)
            }
        }

        private fun writeAudioData(state: AudioTrackState, data: ByteArray, size: Int) {
            val track = state.track
            if (track.state != AudioTrack.STATE_INITIALIZED) return

            // -------------------------------------------------------------
            // DSD 处理流程 (全面 DirectBuffer 化)
            // -------------------------------------------------------------
            if (state.format?.isDsd() == true) {

                // 1. 准备输入 Buffer (Direct Memory)
                // 这一步是将 Java Heap 数据拷贝到 Native Heap 的唯一一次拷贝
                // 后续所有 JNI 处理都将在 Native Heap 中进行，无额外拷贝
                directInputBuffer = ensureBufferCapacity(directInputBuffer, size)
                val inBuf = directInputBuffer!!
                inBuf.put(data, 0, size)
                // 注意：Limit 已经在 put 时自动增加，无需手动 setLimit，但 JNI 需要从头读
                // 虽然 JNI 拿的是 address，但保持 buffer 状态正确是好习惯

                // 2. 准备输出 Buffer
                // 输出大小通常与输入相同 (Native/DoP)，或者是重采样后的大小 (D2P)
                // D2P 降采样时输出会变小，但为了安全，给足空间
                directOutputBuffer = ensureBufferCapacity(directOutputBuffer, size * 2) // 预留足够空间
                val outBuf = directOutputBuffer!!

                var bytesWritten = 0

                if (state.d2pFallback) {
                    // ==========================================
                    // 模式 A: DSD 转 PCM (软解) - 零拷贝版
                    // ==========================================
                    // 使用新增加的 processD2pDirect 接口
                    bytesWritten = dsdResampler?.processD2pDirect(inBuf, size, outBuf) ?: 0

                } else {
                    // ==========================================
                    // 模式 B: DSD 直通 (Native / DoP) - 零拷贝版
                    // ==========================================
                    if (size < 8) return

                    val channels = state.format.channels

                    if (isDoPEnabled) {
                        // --- 子模式 B1: DoP ---
                        bytesWritten = DsdResampler.nativePackDoPDirect(
                            true, // MSBF
                            inBuf,
                            size,
                            outBuf
                        )
                    } else if (i2sFourChannel || channels == 4) {
                        // --- 子模式 B2: 4声道 Native (I2S 硬件或源本身 4 声道) ---
                        bytesWritten = DsdResampler.nativePack4ChannelNativeDirect(
                            true, // MSBF
                            inBuf,
                            size,
                            outBuf
                        )
                    } else {
                        // --- 子模式 B3: 双声道 Native (最常用) ---
                        bytesWritten = DsdResampler.nativePackNativeDirect(
                            true, // MSBF
                            inBuf,
                            size,
                            outBuf
                        )
                    }
                }

                // 3. 写入 AudioTrack (Blocking + DirectBuffer)
                // 这是最高效的写入方式，避免了 Java 层再次创建 ByteArray
                if (bytesWritten > 0) {
                    // 必须设置 limit，告诉 AudioTrack 有多少有效数据
                    outBuf.position(0)
                    outBuf.limit(bytesWritten)

                    val writeMode = audioTrackWriteMode(state) ?: return
                    val written = track.write(outBuf, bytesWritten, writeMode)
                    if (written > 0) synchronized(audioTrackStateLock) {
                        state.clock.wrote(written.toLong() / state.bytesPerFrame)
                    }
                    if (written == AudioTrack.ERROR_DEAD_OBJECT) {
                        handleDeadAudioTrack(track)
                    }
                }

            } else {
                // Native supplies PCM in the format announced by onStreamFormatChanged.
                var offset = 0
                while (offset < size) {
                    val writeMode = audioTrackWriteMode(state) ?: return
                    val written = track.write(data, offset, size - offset, writeMode)
                    if (written <= 0) {
                        if (written == AudioTrack.ERROR_DEAD_OBJECT) {
                            handleDeadAudioTrack(track)
                            return
                        }
                        // A paused track with a full prefill buffer can return zero.
                        if (written < 0) Timber.e("PCM AudioTrack write failed: %d", written)
                        return
                    }
                    synchronized(audioTrackStateLock) {
                        state.clock.wrote(written.toLong() / state.bytesPerFrame)
                    }
                    offset += written
                }
            }
        }

        override fun onPlayStateChanged(state: Int) {
            if (state != 0 && !outputAllowed) return
            if (playbackController != null) {
                playbackController?.onPlayStateChanged(state)
                return
            }
            when (state) {
                1 -> {
                    synchronized(audioTrackControlLock) {
                        if (!outputAllowed) return
                        synchronized(audioTrackStateLock) { playing = false; sinkActive = true }
                        // RAAT STOPPED means rendering silence, not stopping the hardware clock.
                        startAudioTrackIfNeeded()
                    }
                    remoteCallbacks.dispatch(RoonCallbackConnection.Kind.PLAY_STATE) { it.onPlayStateChanged(RoonPlayState.PAUSED) }
                }

                2 -> {
                    synchronized(audioTrackControlLock) {
                        if (!outputAllowed) return
                        synchronized(audioTrackStateLock) { playing = true; sinkActive = true }
                        startAudioTrackIfNeeded()
                    }
                    remoteCallbacks.dispatch(RoonCallbackConnection.Kind.PLAY_STATE) { it.onPlayStateChanged(RoonPlayState.PLAYING) }
                }

                0 -> {
                    synchronized(audioTrackControlLock) {
                        synchronized(audioTrackStateLock) { playing = false; sinkActive = false }
                        releaseAudioTrack()
                        synchronized(audioTrackStateLock) { clockEpochNs = 0L }
                        currentStreamFormat = null
                    }
                    remoteCallbacks.dispatch(RoonCallbackConnection.Kind.PLAY_STATE) { it.onPlayStateChanged(RoonPlayState.STOPPED) }
                }
            }
        }

        override fun onMetadataChanged(metadata: String) {
            remoteCallbacks.dispatch(RoonCallbackConnection.Kind.METADATA) {
                it.onMetadataChanged(gson.fromJson(metadata, RoonMetadata::class.java))
            }
        }

        override fun onArtworkChanged(mimeType: String, data: ByteArray) {
            Timber.d("onArtworkChanged $mimeType ${data.size}")
            remoteCallbacks.dispatch(RoonCallbackConnection.Kind.ARTWORK) { it.onArtworkChanged(mimeType, data) }
        }

        override fun onStreamFormatChanged(streamFormat: StreamFormat) {
            if (!outputAllowed) return
            Timber.d("onStreamFormatChanged $streamFormat")
            remoteCallbacks.dispatch(RoonCallbackConnection.Kind.FORMAT) { it.onStreamFormatChanged(streamFormat) }
            if (playbackController != null) {
                playbackController?.onStreamFormatChanged(streamFormat)
                return
            }
            synchronized(audioTrackControlLock) {
                if (!outputAllowed) return
                releaseAudioTrack()
                currentStreamFormat = streamFormat

                var sampleRate: Int
                var encoding: Int
                isD2PFallback = false

                when (streamFormat.sampleType.lowercase()) {
                    "pcm" -> {
                        sampleRate = streamFormat.sampleRate
                        encoding = when (streamFormat.bitsPerSample) {
                            8 -> AudioFormat.ENCODING_PCM_8BIT
                            24 -> AudioFormat.ENCODING_PCM_24BIT_PACKED
                            32 -> AudioFormat.ENCODING_PCM_32BIT
                            else -> AudioFormat.ENCODING_PCM_16BIT
                        }
                        initAudioTrackSafe(sampleRate, streamFormat.channels, encoding)
                    }

                    "dsd" -> {
                        try {
                            val dsdInPcmRate = streamFormat.sampleRate / 32
                            val nativeEncoding = AudioFormat.ENCODING_DSD
                            // I2S 硬件要求 4 声道布局；否则按源声道数(通常立体声)。
                            val dsdChannels = if (i2sFourChannel) 4 else streamFormat.channels
                            Timber.i("[DSD] init Native DSD: rawRate=${streamFormat.sampleRate} trackRate=$dsdInPcmRate ch=$dsdChannels i2s=$i2sFourChannel")
                            initAudioTrackSafe(dsdInPcmRate, dsdChannels, nativeEncoding)
                            Timber.i("[DSD] AudioTrack Native DSD OK")
                        } catch (e: Exception) {
                            Timber.w(
                                e,
                                "[DSD] Native DSD init failed, falling back to D2P: rawRate=${streamFormat.sampleRate} ch=${streamFormat.channels}"
                            )
                            isD2PFallback = true
                            if (dsdResampler == null) dsdResampler = DsdResampler()
                            var targetRate = streamFormat.sampleRate / 32
                            if (targetRate > 192000) targetRate = 192000
                            dsdResampler?.init(streamFormat.sampleRate, targetRate, 16)
                            initAudioTrackSafe(
                                targetRate,
                                streamFormat.channels,
                                AudioFormat.ENCODING_PCM_16BIT
                            )
                        }
                    }
                }

                // 若是播放中收到的格式变更（如 MQA 检出后以 2×/32bit 重报），重建后立即续播。
                if (sinkActive) {
                    startAudioTrackIfNeeded()
                }
            }
        }
    }

    private interface RaatJniBridgeCallback {
        fun onOutputSetup(): Boolean
        fun onOutputClock(): LongArray?
        fun onVolumeStateChanged(volumeState: VolumeState)
        fun onAudioDataChanged(data: ByteArray, size: Int)
        fun onPlayStateChanged(state: Int)
        fun onMetadataChanged(metadata: String)
        fun onStreamFormatChanged(streamFormat: StreamFormat)
        fun onArtworkChanged(mimeType: String, data: ByteArray)
    }

    /** A soft RAAT stop renders silence; the existing hardware clock must keep its running phase. */
    private fun startAudioTrackIfNeeded() {
        val track = audioTrack ?: return
        if (track.playState != AudioTrack.PLAYSTATE_PLAYING) track.play()
    }

    private fun audioTrackWriteMode(state: AudioTrackState): Int? =
        synchronized(audioTrackStateLock) {
            if (!outputAllowed || audioTrackState !== state || state.retired) return@synchronized null
            // Keep setup/pause silence nonblocking so a stalled sink can reach its setup deadline.
            if (playing) AudioTrack.WRITE_BLOCKING else AudioTrack.WRITE_NON_BLOCKING
        }

    // Called with audioTrackControlLock held. Detach first so no new writer can use this track.
    private fun releaseAudioTrack() {
        val state = synchronized(audioTrackStateLock) {
            (audioTrackState ?: return).also {
                // A replacement continues after the old sink's submitted timeline.
                clockEpochNs = it.clock.writtenNs()
                audioTrackState = null
                it.retired = true
                pendingTrackReleases.removeAll { completion -> completion.succeeded }
                pendingTrackReleases.add(it.releaseCompletion)
            }
        }
        try {
            if (state.track.state != AudioTrack.STATE_UNINITIALIZED) {
                // stop() must stay outside the state lock: it interrupts an in-flight write().
                state.track.stop()
            }
        } catch (e: Exception) {
            Timber.e(e, "Error stopping AudioTrack")
        } finally {
            synchronized(audioTrackStateLock) { state.stopCompleted = true }
            releaseRetiredAudioTrack(state)
        }
    }

    private fun samplePresentationClock(state: AudioTrackState) {
        while (true) {
            val active = synchronized(audioTrackStateLock) {
                if (state.retired || state.released || state.dead) return
                state.clockReaders++
                sinkActive && outputAllowed
            }
            try {
                if (active) {
                    // Binder/HAL calls may block; never hold the lock used by RAAT clock reads.
                    val hasTimestamp = runCatching { state.track.getTimestamp(state.timestamp) }.getOrDefault(false)
                    val now = System.nanoTime()
                    val log = synchronized(audioTrackStateLock) {
                        if (state.retired) return@synchronized null
                        state.clock.update(now, state.timestamp.framePosition.takeIf { hasTimestamp },
                            state.timestamp.nanoTime.takeIf { hasTimestamp })
                        if (now - state.lastClockLogNs < 5_000_000_000L) return@synchronized null
                        state.lastClockLogNs = now
                        val played = state.clock.positionNs(now)
                        "presentation-v2 rate=${state.effectiveClockRate} " +
                            "queuedMs=${played?.let { (state.clock.writtenNs() - it) / 1_000_000 }} " +
                            "timestampTrusted=${played != null}"
                    }
                    if (log != null) android.util.Log.println(android.util.Log.INFO, "RoonClock", log)
                }
            } finally {
                synchronized(audioTrackStateLock) { state.clockReaders-- }
                releaseRetiredAudioTrack(state)
            }
            try {
                Thread.sleep(20)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return
            }
        }
    }

    private fun releaseRetiredAudioTrack(state: AudioTrackState) {
        synchronized(audioTrackStateLock) {
            if (!state.retired || !state.stopCompleted || state.writers != 0 || state.clockReaders != 0 || state.released) return
            state.released = true
        }
        runCatching { state.releaseCompletion.release { state.track.release() } }
            .onFailure { Timber.e(it, "Error releasing AudioTrack") }
    }

    private fun handleDeadAudioTrack(failedTrack: AudioTrack) {
        synchronized(audioTrackControlLock) {
            // A previous format's write can finish after a replacement has already been published.
            if (!outputAllowed || audioTrack !== failedTrack) return
            val isPlaying = synchronized(audioTrackStateLock) {
                audioTrackState?.takeIf { it.track === failedTrack }?.dead = true
                playing
            }
            if (!deadTrackRecoveryPolicy.shouldRecreate(outputAllowed = outputAllowed, playing = isPlaying)) {
                Timber.w(
                    "AudioTrack dead object encountered (playing=%b); releasing without recreating",
                    isPlaying,
                )
                releaseAudioTrack()
                return
            }
            Timber.w("AudioTrack dead object encountered; recreating AudioTrack...")
            val fmt = currentStreamFormat ?: return
            releaseAudioTrack()
            runCatching {
                when (fmt.sampleType.lowercase()) {
                    "pcm" -> {
                        val encoding = when (fmt.bitsPerSample) {
                            8 -> AudioFormat.ENCODING_PCM_8BIT
                            24 -> AudioFormat.ENCODING_PCM_24BIT_PACKED
                            32 -> AudioFormat.ENCODING_PCM_32BIT
                            else -> AudioFormat.ENCODING_PCM_16BIT
                        }
                        initAudioTrackSafe(fmt.sampleRate, fmt.channels, encoding)
                    }
                    "dsd" -> {
                        if (isD2PFallback) {
                            var targetRate = fmt.sampleRate / 32
                            if (targetRate > 192000) targetRate = 192000
                            initAudioTrackSafe(targetRate, fmt.channels, AudioFormat.ENCODING_PCM_16BIT)
                        } else {
                            val dsdInPcmRate = fmt.sampleRate / 32
                            val dsdChannels = if (i2sFourChannel) 4 else fmt.channels
                            initAudioTrackSafe(dsdInPcmRate, dsdChannels, AudioFormat.ENCODING_DSD)
                        }
                    }
                }
                if (sinkActive) {
                    startAudioTrackIfNeeded()
                }
            }.onFailure { Timber.e(it, "Failed to recreate AudioTrack after dead object") }
        }
    }

    @Throws(Exception::class)
    private fun initAudioTrackSafe(
        sampleRate: Int,
        channelCount: Int,
        encoding: Int,
    ) {
        val channelConfig = when (channelCount) {
            1 -> AudioFormat.CHANNEL_OUT_MONO
            4 -> AudioFormat.CHANNEL_OUT_QUAD
            else -> AudioFormat.CHANNEL_OUT_STEREO
        }

        // getMinBufferSize 对 ENCODING_DSD 在部分设备会返回 ERROR(<=0)，必须兜底，
        // 否则 setBufferSizeInBytes(<=0) 会抛 IllegalArgumentException。
        val minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, encoding)
            .takeIf { it > 0 } ?: (32 * 1024)

        val bytesPerFrame = channelCount * when (encoding) {
            AudioFormat.ENCODING_PCM_8BIT -> 1
            AudioFormat.ENCODING_PCM_16BIT -> 2
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> 3
            AudioFormat.ENCODING_PCM_32BIT,
            AudioFormat.ENCODING_DSD -> 4
            else -> 2
        }
        val raatChunkBytes = (sampleRate / 20) * bytesPerFrame

        // Retain the scheduling/GC safety margin; the presentation clock accounts for the queue.
        val halfSecondBytes = (sampleRate.toLong() * bytesPerFrame / 2).toInt()
        val bufferSize = if (encoding == AudioFormat.ENCODING_DSD) {
            maxOf(minBufferSize * 4, raatChunkBytes * 6).coerceAtMost(4 * 1024 * 1024).coerceAtLeast(minBufferSize * 2)
        } else {
            maxOf(minBufferSize * 2, raatChunkBytes * 6, halfSecondBytes).coerceAtMost(4 * 1024 * 1024)
        }

        Timber.d("Creating AudioTrack: rate=$sampleRate, ch=$channelConfig, enc=$encoding, minBuf=$minBufferSize, buf=$bufferSize")

        val builder = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(encoding)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelConfig)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufferSize)

        builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_NONE)

        val track = builder.build()
        if (track.state != AudioTrack.STATE_INITIALIZED) {
            track.release()
            throw UnsupportedOperationException("AudioTrack state is not INITIALIZED")
        }
        val pcm = currentStreamFormat?.sampleType.equals("pcm", ignoreCase = true)
        val primedFrames = try {
            if (pcm) primePcmTrack(bufferSize, bytesPerFrame) { silence, size ->
                track.write(silence, 0, size, AudioTrack.WRITE_NON_BLOCKING)
            } else 0L
        } catch (error: Exception) {
            track.release()
            throw error
        }
        val state = synchronized(audioTrackStateLock) {
            AudioTrackState(
                track = track,
                format = currentStreamFormat,
                d2pFallback = isD2PFallback,
                epochNs = clockEpochNs,
                startupFrames = if (pcm) {
                    minOf(bufferSize / bytesPerFrame, sampleRate / 2)
                } else 0,
                i2sFourChannel = i2sFourChannel,
            ).also {
                it.clock.wrote(primedFrames)
                audioTrackState = it
            }
        }
        Thread({ samplePresentationClock(state) }, "RoonClock").apply { isDaemon = true }.start()
    }
}
