package com.qytech.roon

import android.os.IBinder
import android.os.RemoteException
import java.util.concurrent.Executor
import timber.log.Timber

/**
 * Owns the host's single status subscription across Binder and JNI callback threads.
 * Notification failure drops only that registration; playback and a replacement host survive.
 */
internal class RoonCallbackConnection(private val executor: Executor) {
    enum class Kind { METADATA, ARTWORK, VOLUME, FORMAT, PLAY_STATE }

    private class Notice(val kind: Kind, val send: (IRoonCallback) -> Unit)

    private val pending = ArrayDeque<Notice>()
    private var draining = false
    private val lock = Any()
    private var current: Registration? = null

    /** Replaces the subscription, including a new generation on the same host Binder. */
    fun register(callback: IRoonCallback) = synchronized(lock) {
        clearLocked()
        val registration = Registration(callback)
        try {
            registration.binder.linkToDeath(registration, 0)
            current = registration
        } catch (error: RemoteException) {
            Timber.w(error, "Roon callback client died before registration")
        }
    }

    /** AIDL creates distinct proxy wrappers for the same Binder on separate transactions. */
    fun unregister(callback: IRoonCallback) = synchronized(lock) {
        if (current?.binder == callback.asBinder()) clearLocked()
    }

    /** Detaches the host when this endpoint is released. */
    fun clear() = synchronized(lock) {
        clearLocked()
    }

    /** Enqueues host notifications without running Binder or metadata parsing on the RAAT loop. */
    fun dispatch(kind: Kind, action: (IRoonCallback) -> Unit) {
        synchronized(lock) {
            if (current == null) return
            if (kind == Kind.METADATA && pending.lastOrNull()?.kind == Kind.METADATA) {
                pending.removeLast()
            }
            if (pending.size == MAX_PENDING_NOTICES) {
                // A stalled observer can catch up to the latest snapshot of each kind, in order.
                val newest = pending.asReversed().distinctBy { it.kind }.asReversed()
                pending.clear()
                pending.addAll(newest)
            }
            pending.addLast(Notice(kind, action))
            if (draining) return
            draining = true
        }
        executor.execute(::deliverPending)
    }

    private fun deliverPending() {
        while (true) {
            val (registration, notice) = synchronized(lock) {
                val target = current
                if (target == null || pending.isEmpty()) {
                    draining = false
                    return
                }
                target to pending.removeFirst()
            }
            try {
                notice.send(registration.callback)
            } catch (error: RemoteException) {
                synchronized(lock) {
                    if (current === registration) clearLocked()
                }
                Timber.w(error, "Roon callback delivery failed; dropping disconnected subscription")
            } catch (error: RuntimeException) {
                Timber.w(error, "Roon host notification failed: %s", notice.kind)
            }
        }
    }

    private fun clearLocked() {
        val registration = current ?: return
        current = null
        pending.clear()
        registration.binder.unlinkToDeath(registration, 0)
    }

    private inner class Registration(val callback: IRoonCallback) : IBinder.DeathRecipient {
        val binder: IBinder = callback.asBinder()

        override fun binderDied() {
            synchronized(lock) {
                // Binder has already removed its death recipients; do not unlink it again.
                if (current === this) {
                    current = null
                    pending.clear()
                }
            }
        }
    }
    private companion object {
        const val MAX_PENDING_NOTICES = 32
    }
}
