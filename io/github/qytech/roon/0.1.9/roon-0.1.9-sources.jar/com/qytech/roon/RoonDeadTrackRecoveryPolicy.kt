package com.qytech.roon

import java.util.concurrent.TimeUnit

/**
 * Guards against Direct/Offload AudioTrack recreation thrashing on `ERROR_DEAD_OBJECT`.
 *
 * A dead track encountered while not actively playing (e.g. during RAAT's post-pause
 * silence tail or initial setup prefill) must never be recreated, or it will steal the
 * hardware output path back from the newly active audio owner. Even while playing, a
 * tight burst of dead-track errors indicates unrecoverable contention rather than a
 * transient glitch and should stop recreating once [maxAttemptsInWindow] is exceeded.
 */
internal class RoonDeadTrackRecoveryPolicy(
    private val maxAttemptsInWindow: Int = DEFAULT_MAX_ATTEMPTS,
    private val windowNs: Long = DEFAULT_WINDOW_NS,
    private val nanoTime: () -> Long = System::nanoTime,
) {
    private val recentAttemptTimestampsNs = ArrayDeque<Long>()

    fun shouldRecreate(outputAllowed: Boolean, playing: Boolean): Boolean {
        if (!outputAllowed || !playing) return false
        val nowNs = nanoTime()
        while (recentAttemptTimestampsNs.isNotEmpty() && nowNs - recentAttemptTimestampsNs.first() > windowNs) {
            recentAttemptTimestampsNs.removeFirst()
        }
        if (recentAttemptTimestampsNs.size >= maxAttemptsInWindow) {
            return false
        }
        recentAttemptTimestampsNs.addLast(nowNs)
        return true
    }

    fun reset() {
        recentAttemptTimestampsNs.clear()
    }

    companion object {
        const val DEFAULT_MAX_ATTEMPTS = 2
        val DEFAULT_WINDOW_NS: Long = TimeUnit.SECONDS.toNanos(3)
    }
}
