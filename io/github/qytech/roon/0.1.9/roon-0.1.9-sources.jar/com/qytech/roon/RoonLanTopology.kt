package com.qytech.roon

import java.util.Collections

/**
 * Compares observed LAN addresses with the topology used to start the endpoint.
 * Inputs are normalized IPv4 signatures including interface name and prefix length;
 * address filtering and interface discovery belong to the platform adapter.
 */
internal class RoonLanTopology {
    private val observed = mutableMapOf<Long, Set<String>>()
    private var started: Map<Long, Set<String>>? = null

    /** Returns true only for a changed observation that differs from an active endpoint's baseline. */
    @Synchronized
    fun update(handle: Long, addresses: Set<String>): Boolean {
        if (addresses.isEmpty()) return remove(handle)
        val snapshot = addresses.toSet()
        if (observed[handle] == snapshot) return false
        observed[handle] = snapshot
        return started?.let { it != observed } == true
    }

    /** Removes one observed network; an unknown handle is unchanged. */
    @Synchronized
    fun remove(handle: Long): Boolean {
        if (observed.remove(handle) == null) return false
        return started?.let { it != observed } == true
    }

    /** Returns an immutable copy that can be captured before a Binder call without holding this lock. */
    @Synchronized
    fun snapshot(): Map<Long, Set<String>> = Collections.unmodifiableMap(
        observed.mapValues { (_, addresses) -> Collections.unmodifiableSet(addresses.toSet()) },
    )

    /** Marks a pre-start snapshot and reports topology changes that arrived while starting. */
    @Synchronized
    fun endpointStarted(snapshot: Map<Long, Set<String>> = snapshot()): Boolean {
        started = snapshot.mapValues { (_, addresses) -> addresses.toSet() }
        return started != observed
    }

    /** Drops the endpoint baseline while retaining observations for its replacement. */
    @Synchronized
    fun endpointStopped() {
        started = null
    }

    /** Clears both endpoint ownership and observed networks. */
    @Synchronized
    fun clear() {
        started = null
        observed.clear()
    }
}
