package com.qytech.roon

import android.os.IBinder
import android.os.RemoteException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import timber.log.Timber

/**
 * Keeps one output setup pending while its host reconnects, within one bounded deadline.
 * The supplied lock also protects the caller's stop/takeover state and output admission.
 */
internal class RoonOutputHandshake(
    private val lock: Any,
    private val isSetupAllowed: () -> Boolean,
    private val timeoutNs: Long = TimeUnit.SECONDS.toNanos(5),
    private val nanoTime: () -> Long = System::nanoTime,
    private val onBegin: () -> Unit = {},
) {
    private var required = false
    private var owner: Registration? = null
    private var pending: Setup? = null

    /** A replacement host invalidates the old request, but keeps the setup's original deadline. */
    fun register(callback: IRoonOutputCallback) = synchronized(lock) {
        required = true
        detachOwnerLocked()
        val registration = Registration(callback)
        try {
            registration.binder.linkToDeath(registration, 0)
            owner = registration
        } catch (error: RemoteException) {
            Timber.w(error, "Roon output host died before registration")
        }
        ownerChangedLocked()
    }

    /** Returns true only when this Binder owned the subscription being removed. */
    fun unregister(callback: IRoonOutputCallback): Boolean = synchronized(lock) {
        if (owner?.binder != callback.asBinder()) return@synchronized false
        cancelLocked()
        detachOwnerLocked()
        true
    }

    /** Permanently invalidates the pending setup while retaining the host for future setups. */
    fun cancel() = synchronized(lock) { cancelLocked() }

    /** Ends pending work and releases the host's death listener on endpoint teardown. */
    fun clear() = synchronized(lock) {
        cancelLocked()
        detachOwnerLocked()
    }

    /**
     * Invokes the host outside the lock. A failed transport waits for a new registration;
     * an explicit rejection is final. Successful admission is committed under the shared lock.
     */
    fun prepare(onReady: () -> Unit, send: (IRoonOutputCallback, Request) -> Unit): Boolean {
        val setup = synchronized(lock) {
            cancelLocked()
            if (!isSetupAllowed()) return false
            onBegin()
            if (!required && owner == null) {
                onReady()
                return true
            }
            Setup(nanoTime() + timeoutNs).also { pending = it }
        }
        try {
            while (true) {
                var toSend: Request? = null
                val changed = synchronized(lock) {
                    if (pending !== setup || !isSetupAllowed() || setup.rejected ||
                        nanoTime() >= setup.deadline) return false
                    val current = setup.request
                    if (current?.ready == true && owner === current.registration) {
                        pending = null
                        onReady()
                        return true
                    }
                    if (setup.changed.count == 0L) setup.changed = CountDownLatch(1)
                    owner?.let { registration ->
                        if (current == null || current.registration !== registration) {
                            toSend = Request(setup, registration).also { setup.request = it }
                        }
                    }
                    setup.changed
                }
                toSend?.let { request ->
                    try {
                        send(request.registration.callback, request)
                    } catch (error: RemoteException) {
                        synchronized(lock) {
                            if (owner === request.registration) {
                                detachOwnerLocked()
                                ownerChangedLocked()
                            }
                        }
                        Timber.w(error, "Roon output host disconnected; awaiting replacement")
                    }
                }
                changed.await((setup.deadline - nanoTime()).coerceAtLeast(0L), TimeUnit.NANOSECONDS)
            }
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            return false
        } finally {
            synchronized(lock) { if (pending === setup) cancelLocked() }
        }
    }

    private fun cancelLocked() {
        pending?.changed?.countDown()
        pending = null
    }

    private fun detachOwnerLocked() {
        val previous = owner ?: return
        owner = null
        previous.binder.unlinkToDeath(previous, 0)
    }

    private fun ownerChangedLocked() {
        pending?.let {
            it.request = null
            it.changed.countDown()
        }
    }

    internal class Setup(val deadline: Long) {
        var changed = CountDownLatch(1)
        var request: Request? = null
        var rejected = false
    }

    internal inner class Registration(val callback: IRoonOutputCallback) : IBinder.DeathRecipient {
        val binder: IBinder = callback.asBinder()

        override fun binderDied() = synchronized(lock) {
            if (owner === this) {
                owner = null
                ownerChangedLocked()
            }
        }
    }

    /** Only the current host's unexpired request can acknowledge output ownership. */
    internal inner class Request internal constructor(
        internal val setup: Setup,
        internal val registration: Registration,
    ) {
        internal var ready: Boolean? = null

        fun isCurrent(): Boolean = synchronized(lock) {
            pending === setup && setup.request === this && owner === registration &&
                ready == null && !setup.rejected && isSetupAllowed() &&
                nanoTime() < setup.deadline
        }

        fun complete(ready: Boolean) = synchronized(lock) {
            if (!isCurrent()) return@synchronized
            this.ready = ready
            if (!ready) setup.rejected = true
            setup.changed.countDown()
        }
    }
}
