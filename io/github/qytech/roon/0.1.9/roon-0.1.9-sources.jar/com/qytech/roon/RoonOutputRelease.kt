package com.qytech.roon

import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Completion means the platform release call returned successfully, not just that it started. */
internal class RoonOutputRelease {
    private val completed = CountDownLatch(1)
    @Volatile var succeeded = false
        private set

    fun release(action: () -> Unit) {
        try {
            action()
            succeeded = true
        } finally {
            completed.countDown()
        }
    }

    fun awaitUntil(deadlineNs: Long): Boolean =
        completed.await((deadlineNs - System.nanoTime()).coerceAtLeast(0L), TimeUnit.NANOSECONDS) && succeeded
}

/** One deadline for every retired track, including readers left over from an earlier replacement. */
internal fun awaitRoonOutputReleases(releases: List<RoonOutputRelease>, timeoutNs: Long): Boolean {
    val deadline = System.nanoTime() + timeoutNs
    return try {
        releases.all { it.awaitUntil(deadline) }
    } catch (_: InterruptedException) {
        Thread.currentThread().interrupt()
        false
    }
}
