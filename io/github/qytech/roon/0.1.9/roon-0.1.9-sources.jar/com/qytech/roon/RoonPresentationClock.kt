package com.qytech.roon

/** Hardware samples and reads are serialized by the owner's short state lock. */
internal class RoonPresentationClock(
    private val sampleRate: Int,
    private val epochNs: Long = 0L,
    private val startupFrames: Int = 0,
) {
    var writtenFrames = 0L
        private set
    private var previousTimestampFrame = -1L
    private var previousTimestampNs = 0L
    private var stableFromFrame = 0L
    private var goodTimestamps = 0
    private var anchorFrame = 0L
    private var anchorNs = 0L
    private var lastPositionNs = epochNs
    private var lastQueryNs = 0L

    fun wrote(frames: Long) { writtenFrames += frames }

    /** Called by the sampler after getTimestamp, never from RAAT's clock callback. */
    fun update(nowNs: Long, timestampFrame: Long?, timestampNs: Long?) {
        if (timestampFrame == null || timestampNs == null || timestampNs <= 0L ||
            timestampNs > nowNs || nowNs - timestampNs > 200_000_000L ||
            timestampFrame !in 0L..writtenFrames) {
            goodTimestamps = 0
            previousTimestampFrame = -1L
            return
        }
        val elapsed = timestampNs - previousTimestampNs
        val frames = timestampFrame - previousTimestampFrame
        if (previousTimestampFrame < 0L || elapsed < 0L || frames < 0L) {
            goodTimestamps = 0
            previousTimestampFrame = timestampFrame
            previousTimestampNs = timestampNs
        } else if (elapsed >= 20_000_000L) {
            val expected = elapsed.toDouble() * sampleRate / 1_000_000_000.0
            if (kotlin.math.abs(frames - expected) <= maxOf(2.0, expected * 0.05)) {
                if (goodTimestamps == 0) stableFromFrame = previousTimestampFrame
                goodTimestamps = (goodTimestamps + 1).coerceAtMost(3)
            } else {
                goodTimestamps = 0
            }
            previousTimestampFrame = timestampFrame
            previousTimestampNs = timestampNs
            // Cold PCM can advance at nominal rate on a temporary HAL phase. Qualify across
            // the startup queue; an invalid interval starts that observation window again.
            if (goodTimestamps >= 3 && (anchorNs != 0L || timestampFrame - stableFromFrame >= startupFrames)) {
                anchorFrame = timestampFrame
                anchorNs = timestampNs
            }
        }
    }

    /** No hardware calls: extrapolate only a recently qualified presentation sample. */
    fun positionNs(nowNs: Long): Long? {
        if (anchorNs == 0L || nowNs < anchorNs || nowNs - anchorNs > 200_000_000L) return null
        val presented = (epochNs + framesToNs(anchorFrame) + nowNs - anchorNs)
            .coerceAtMost(writtenNs())
        lastPositionNs = maxOf(lastPositionNs, presented)
        lastQueryNs = nowNs
        return lastPositionNs
    }

    /**
     * Fallback presentation position when hardware timestamps have not yet qualified
     * or are momentarily delayed by GC pauses / HAL WOULD_BLOCK transitions.
     * Strictly monotonic, advances in real-time, bounded by [epochNs, writtenNs()].
     */
    fun fallbackPositionNs(nowNs: Long): Long {
        if (anchorNs != 0L && nowNs >= anchorNs) {
            val presented = (epochNs + framesToNs(anchorFrame) + nowNs - anchorNs)
                .coerceAtMost(writtenNs())
            lastPositionNs = maxOf(lastPositionNs, presented)
            lastQueryNs = nowNs
            return lastPositionNs
        }
        val elapsed = if (lastQueryNs > 0L && nowNs > lastQueryNs) nowNs - lastQueryNs else 0L
        lastQueryNs = nowNs
        val presented = (lastPositionNs + elapsed).coerceAtMost(writtenNs())
        lastPositionNs = maxOf(lastPositionNs, presented)
        return lastPositionNs
    }

    fun writtenNs(): Long = epochNs + framesToNs(writtenFrames)

    private fun framesToNs(frames: Long): Long =
        frames / sampleRate * 1_000_000_000L + frames % sampleRate * 1_000_000_000L / sampleRate
}

/** Primes a new PCM sink before play(), without blocking or counting an unwritten silence tail. */
internal fun primePcmTrack(capacityBytes: Int, bytesPerFrame: Int, write: (ByteArray, Int) -> Int): Long {
    if (bytesPerFrame <= 0 || capacityBytes < bytesPerFrame) return 0L
    val alignedCapacity = capacityBytes / bytesPerFrame * bytesPerFrame
    val blockBytes = minOf(alignedCapacity, 32 * 1024) / bytesPerFrame * bytesPerFrame
    if (blockBytes == 0) return 0L
    val silence = ByteArray(blockBytes)
    var accepted = 0
    while (alignedCapacity - accepted >= bytesPerFrame) {
        val count = minOf(blockBytes, alignedCapacity - accepted)
        val bytes = write(silence, count)
        if (bytes <= 0) break
        accepted += bytes
        if (bytes < count) break
    }
    return accepted.toLong() / bytesPerFrame
}
