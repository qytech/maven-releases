package com.qytech.roon

import timber.log.Timber

/**
 * Admits starts only until this dedicated endpoint process begins retirement.
 * The SDK's device-stop path can corrupt pending libuv close handles; an endpoint
 * therefore releases its audio output and exits instead of destroying that loop.
 * A new process owns the next endpoint, including fresh JNI and SDK globals.
 */
internal class RoonProcessLifetime {
    private var retiring = false

    /** Serializes start admission with retirement; callers must reconnect after rejection. */
    @Synchronized
    fun start(startEndpoint: () -> Unit): Boolean {
        if (retiring) return false
        startEndpoint()
        return true
    }

    /** Queues exactly one output release, then exits even if the sink cannot release cleanly. */
    @Synchronized
    fun retire(
        enqueue: (() -> Unit) -> Unit,
        releaseOutput: () -> Boolean,
        terminate: () -> Unit,
    ) {
        if (retiring) return
        retiring = true
        enqueue {
            try {
                if (!releaseOutput()) Timber.w("Roon output did not release cleanly before process retirement")
            } catch (error: Exception) {
                Timber.w(error, "Roon output release failed before process retirement")
            } finally {
                terminate()
            }
        }
    }
}
