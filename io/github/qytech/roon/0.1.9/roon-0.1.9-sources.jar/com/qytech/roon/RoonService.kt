package com.qytech.roon

import android.app.Application
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.DeadObjectException
import android.os.Process
import com.qytech.roon.model.SignalPath
import com.qytech.roon.model.SupportedFormat
import timber.log.Timber

/**
 * @author Administrator
 * @date 2025/6/19 10:51
 */
class RoonService : Service() {
    private val roonApp = RoonApp()

    private companion object {
        // Shared by Service instances until the dedicated process has actually exited.
        val processLifetime = RoonProcessLifetime()
    }

    /** Retires only the manifest-declared Roon process, without entering RAAT device-stop. */
    private fun retireEndpoint() {
        check(Application.getProcessName() == "$packageName:roon_process") {
            "RoonService must run in its dedicated :roon_process"
        }
        roonApp.retireProcess(processLifetime) {
            Timber.i("Roon endpoint process retiring after output release")
            Process.killProcess(Process.myPid())
        }
    }

    private val binder = object : IRoonService.Stub() {
        override fun startRoon(
            name: String,
            uuid: String,
            serial: String,
            version: String,
            model: String,
            vendor: String,
            maxDsdRate: Int,
            supportedFormats: List<SupportedFormat>,
            signalPaths: List<SignalPath>,
        ) {
            val accepted = processLifetime.start {
                roonApp.start(
                    this@RoonService,
                    name,
                    uuid,
                    serial,
                    version,
                    model,
                    vendor,
                    maxDsdRate,
                    supportedFormats,
                    signalPaths = signalPaths
                )
            }
            if (!accepted) throw DeadObjectException("Roon endpoint process is retiring")
        }

        override fun stopRoon() {
            retireEndpoint()
        }

        override fun updateSignalPath(signalPath: SignalPath) {
            roonApp.updateSignalPath(signalPath)
        }

        override fun next() {
            roonApp.next()
        }

        override fun previous() {
            roonApp.previous()
        }

        override fun pause() {
            roonApp.pause()
        }

        override fun releasePlaybackOutput(): Boolean = roonApp.releasePlaybackOutput()

        override fun registerOutputCallback(callback: IRoonOutputCallback?) {
            callback?.let(roonApp::registerOutputCallback)
        }

        override fun unregisterOutputCallback(callback: IRoonOutputCallback?) {
            callback?.let(roonApp::unregisterOutputCallback)
        }

        override fun play() {
            roonApp.play()
        }

        override fun playPause() {
            roonApp.playPause()
        }

        override fun seek(position: Int) {
            roonApp.seek(position)
        }

        override fun toggleLoop() {
            roonApp.toggleLoop()
        }

        override fun toggleShuffle() {
            roonApp.toggleShuffle()
        }

        override fun registerCallback(callback: IRoonCallback?) {
            Timber.d("registerCallback: $callback")
            callback?.let {
                roonApp.registerCallback(it)
            }
        }

        override fun unregisterCallback(callback: IRoonCallback?) {
            Timber.d("unregisterCallback: $callback")
            callback?.let {
                roonApp.unregisterCallback(it)
            }
        }

        override fun registerPlaybackController(controller: IRoonPlaybackController?) {
            controller?.let {
                roonApp.registerPlaybackController(it)
            }
        }

        override fun unregisterPlaybackController(controller: IRoonPlaybackController?) {
            controller?.let {
                roonApp.unregisterPlaybackController(it)
            }
        }

        override fun reportVolumeState(volume: Double, muted: Boolean) {
            Timber.d("[Volume E3] RoonService.reportVolumeState: volume=$volume muted=$muted")
            roonApp.reportVolume(volume, muted)
        }
    }

    override fun onBind(p0: Intent?): IBinder = binder

    override fun onDestroy() {
        super.onDestroy()
        retireEndpoint()
    }
}
