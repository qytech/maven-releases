package com.qytech.roon

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.ConnectivityManager
import android.net.Network
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.RemoteException
import com.qytech.roon.model.SignalPath
import com.qytech.roon.model.SupportedFormat
import timber.log.Timber
import java.lang.ref.WeakReference
import java.net.Inet4Address
import java.net.InetAddress


/**
 * @author Administrator
 * @date 2025/6/19 11:05
 */
object RoonServiceManager {

    private const val NETWORK_SETTLE_MS = 500L

    private lateinit var contextReference: WeakReference<Context>
    private val mainHandler by lazy { Handler(Looper.getMainLooper()) }

    @Volatile private var service: IRoonService? = null
    @Volatile private var retiringService: IRoonService? = null
    private var sourceStateAppliedTo: IRoonService? = null
    private var roonServiceIntent: Intent? = null
    private var bound = false
    private var binding = false
    @Volatile private var userInitiatedUnbind = false
    private var callback: IRoonCallback? = null
    private var playbackController: IRoonPlaybackController? = null
    @Volatile private var outputCallback: IRoonOutputCallback? = null
    private var outputCallbackDelegate: IRoonOutputCallback? = null
    private val outputSelectionLock = Any()
    private var outputDeselected = false
    private var outputSelectionVersion = 0L

    private var pendingStartParams: StartParams? = null
    private var activeStartParams: StartParams? = null
    private var latestVolumeReport: Pair<Double, Boolean>? = null
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var interfaceCallback: ConnectivityManager.NetworkCallback? = null
    private val interfaceNetworks = mutableSetOf<Long>()
    private val lanTopology = RoonLanTopology()
    @Volatile private var initialTopologySettling = false
    private var initialTopologySettler: Runnable? = null
    private var networkAvailable: Boolean? = null
    private var defaultNetworkHandle: Long? = null
    private var endpointNetworkHandle: Long? = null

    private data class StartParams(
        val name: String,
        val uuid: String,
        val serial: String,
        val version: String,
        val model: String,
        val vendor: String,
        val maxDsdRate: Int,
        val supportedFormats: List<SupportedFormat>,
        val signalPaths: List<SignalPath>,
    )


    private val connection: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(
            name: ComponentName?,
            binder: IBinder?,
        ) {
            Timber.d("onServiceConnected: $name")
            if (userInitiatedUnbind ||
                retiringService?.asBinder()?.let { it == binder } == true) return
            service = IRoonService.Stub.asInterface(binder)
            retiringService = null
            endpointNetworkHandle = null
            lanTopology.endpointStopped()
            if (service == null) {
                recoverServiceConnection("null service binder")
                return
            }
            bound = true
            binding = false
            if (!callService("register callbacks") {
                    it.registerCallback(callback)
                    it.registerPlaybackController(playbackController)
                    outputCallback?.let(it::registerOutputCallback)
                }
            ) {
                return
            }
            Timber.d("onServiceConnected: registered callback=$callback, controller=$playbackController")

            // 补发挂起的 startRoon 请求
            pendingStartParams?.let { params ->
                if (networkAvailable == false || initialTopologySettling) return@let
                Timber.d("onServiceConnected: flushing pending startRoon for ${params.name}")
                if (invokeStartRoon(params)) {
                    pendingStartParams = null
                }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            Timber.d("onServiceDisconnected: $name")
            recoverServiceConnection("service disconnected")
        }

        override fun onBindingDied(name: ComponentName?) {
            Timber.w("onBindingDied: $name")
            recoverServiceConnection("binding died")
        }

        override fun onNullBinding(name: ComponentName?) {
            Timber.w("onNullBinding: $name")
            recoverServiceConnection("null binding")
        }
    }

    private val rebindRunnable = Runnable {
        if (!userInitiatedUnbind) {
            Timber.d("Reconnecting to Roon service...")
            bindService()
        }
    }

    /** Restarts once with the latest pending settings after the network settles. */
    private val networkRecoveryRunnable = Runnable {
        val params = pendingStartParams ?: return@Runnable
        if (!userInitiatedUnbind &&
            service != null &&
            bound &&
            networkAvailable == true &&
            !initialTopologySettling &&
            retiringService == null &&
            activeStartParams == params &&
            invokeStartRoon(params)
        ) {
            pendingStartParams = null
        }
    }

    fun init(
        appContext: Context,
        callback: IRoonCallback? = null,
        playbackController: IRoonPlaybackController? = null,
    ) = init(appContext, callback, playbackController, null)

    /** Adds a pre-output handshake while retaining the original standalone initialization API. */
    fun init(
        appContext: Context,
        callback: IRoonCallback?,
        playbackController: IRoonPlaybackController?,
        outputCallback: IRoonOutputCallback?,
    ) = runCatching {
        val previousOutputCallback = this.outputCallback
        this.contextReference = WeakReference(appContext.applicationContext)
        this.callback = callback
        this.playbackController = playbackController
        if (outputCallbackDelegate !== outputCallback) {
            this.outputCallback = outputCallback?.let(::observeOutputSelection)
            outputCallbackDelegate = outputCallback
        }
        userInitiatedUnbind = false
        registerNetworkCallback(appContext.applicationContext)
        Timber.d("init: bound=$bound, service=$service")
        if (!bound) {
            bindService()
        } else {
            callService("refresh callbacks") { currentService ->
                currentService.registerCallback(callback)
                currentService.registerPlaybackController(playbackController)
                if (previousOutputCallback !== this.outputCallback) {
                    previousOutputCallback?.let(currentService::unregisterOutputCallback)
                    this.outputCallback?.let(currentService::registerOutputCallback)
                }
            }
        }
        Unit
    }.onFailure {
        Timber.e(it, "Failed to initialize RoonServiceManager")
    }

    fun release() {
        Timber.d("release: bound=$bound, service=$service")
        userInitiatedUnbind = true
        synchronized(outputSelectionLock) { outputSelectionVersion++ }
        mainHandler.removeCallbacks(rebindRunnable)
        mainHandler.removeCallbacks(networkRecoveryRunnable)
        pendingStartParams = null
        activeStartParams = null
        latestVolumeReport = null
        unregisterNetworkCallback()
        val currentService = service
        runCatching { outputCallback?.let { currentService?.unregisterOutputCallback(it) } }
            .onFailure { Timber.w(it, "Failed to unregister Roon output callback") }
        outputCallback = null
        outputCallbackDelegate = null
        runCatching { currentService?.unregisterCallback(callback) }
            .onFailure { Timber.w(it, "Failed to unregister Roon callback") }
        runCatching { currentService?.unregisterPlaybackController(playbackController) }
            .onFailure { Timber.w(it, "Failed to unregister Roon playback controller") }
        // The dedicated endpoint may exit immediately after this call; detach callbacks first.
        runCatching { currentService?.stopRoon() }
            .onFailure { Timber.w(it, "Failed to stop Roon during release") }
        val context = if (::contextReference.isInitialized) contextReference.get() else null
        if (bound || binding) {
            runCatching { context?.unbindService(connection) }
                .onFailure { Timber.w(it, "Failed to unbind Roon service") }
        }
        roonServiceIntent?.let {
            runCatching { context?.stopService(it) }
                .onFailure { error -> Timber.w(error, "Failed to stop Roon service") }
        }
        service = null
        retiringService = null
        sourceStateAppliedTo = null
        endpointNetworkHandle = null
        roonServiceIntent = null
        bound = false
        binding = false
    }

    fun startRoon(
        name: String,
        uuid: String,
        serial: String,
        version: String,
        model: String,
        vendor: String,
        maxDsdRate: Int,
        supportedFormats: List<SupportedFormat>,
        signalPaths: List<SignalPath> = listOf(
            SignalPath(
                quality = "lossless",
                type = "output",
                method = "usb"
            )
        ),
    ) {
        val params = StartParams(
            name, uuid, serial, version, model, vendor,
            maxDsdRate, supportedFormats, signalPaths
        )
        activeStartParams = params
        val s = service
        if (networkAvailable == false || initialTopologySettling || s == null || !bound || retiringService != null) {
            // service 尚未连接（bindService 异步），缓存参数等连接后补发
            Timber.w("startRoon called but service not connected yet (service=$s, bound=$bound), defer until connected: $name")
            pendingStartParams = params
            return
        }
        Timber.d("startRoon: name=$name, uuid=$uuid, maxDsdRate=$maxDsdRate, formats=${supportedFormats.size}")
        if (invokeStartRoon(params)) {
            pendingStartParams = null
        }
    }

    fun updateSignalPath(signalPath: SignalPath) {
        val params = activeStartParams?.copy(signalPaths = listOf(signalPath)) ?: return
        activeStartParams = params
        if (pendingStartParams != null) pendingStartParams = params
        if (networkAvailable == false ||
            !callService("updateSignalPath") { it.updateSignalPath(signalPath) }
        ) {
            pendingStartParams = params
        }
    }

    private fun invokeStartRoon(params: StartParams): Boolean {
        if (retiringService != null) return false
        Timber.d("invokeStartRoon -> native raatStart for ${params.name}")
        var started = false
        val called = callService("startRoon for ${params.name}") { currentService ->
            // Reassert a deliberate source handoff before a fresh native endpoint is created.
            if (sourceStateAppliedTo !== currentService) {
                val deselected = synchronized(outputSelectionLock) { outputDeselected }
                if (deselected && !currentService.releasePlaybackOutput()) return@callService
                sourceStateAppliedTo = currentService
            }
            val topologyAtStart = lanTopology.snapshot()
            val networkAtStart = defaultNetworkHandle
            currentService.startRoon(
                params.name, params.uuid, params.serial, params.version, params.model,
                params.vendor, params.maxDsdRate, params.supportedFormats, params.signalPaths,
            )
            if (service !== currentService || retiringService != null) return@callService
            endpointNetworkHandle = networkAtStart
            if (lanTopology.endpointStarted(topologyAtStart)) {
                retireNetworkEndpoint("LAN addresses changed during startup")
                return@callService
            }
            started = true
            latestVolumeReport?.let { (volume, muted) -> currentService.reportVolumeState(volume, muted) }
        }
        return called && started
    }

    /** Carries the host's source decision across endpoint replacement without replaying Play. */
    private fun observeOutputSelection(delegate: IRoonOutputCallback): IRoonOutputCallback =
        object : IRoonOutputCallback.Stub() {
            override fun onPreparePlaybackOutput(request: IRoonOutputPreparation) {
                val registration = this
                val endpoint = service
                val version = synchronized(outputSelectionLock) { outputSelectionVersion }
                val forwarded = object : IRoonOutputPreparation.Stub() {
                    private fun ownsSelection(): Boolean = synchronized(outputSelectionLock) {
                        !userInitiatedUnbind && outputCallback === registration &&
                            service === endpoint && retiringService !== endpoint &&
                            outputSelectionVersion == version
                    }
                    override fun isCurrent(): Boolean = ownsSelection() && request.isCurrent
                    override fun complete(ready: Boolean) {
                        val current = ready && isCurrent()
                        val accepted = synchronized(outputSelectionLock) {
                            if (!current || !ownsSelection()) false else {
                                outputDeselected = false
                                true
                            }
                        }
                        request.complete(accepted)
                    }
                }
                delegate.onPreparePlaybackOutput(forwarded)
            }
        }

    fun stopRoon() {
        Timber.d("stopRoon: service=$service")
        mainHandler.removeCallbacks(networkRecoveryRunnable)
        pendingStartParams = null
        activeStartParams = null
        latestVolumeReport = null
        callService("stopRoon") { it.stopRoon() }
    }

    fun play() {
        callService("play") { it.play() }
    }

    fun pause() {
        callService("pause") { it.pause() }
    }

    /** Waits for output release without stopping the endpoint. Must be called off main. */
    fun releasePlaybackOutput(): Boolean {
        synchronized(outputSelectionLock) {
            outputDeselected = true
            outputSelectionVersion++
        }
        var released = false
        val called = callService("releasePlaybackOutput") { released = it.releasePlaybackOutput() }
        return called && released
    }

    fun next() {
        callService("next") { it.next() }
    }

    fun previous() {
        callService("previous") { it.previous() }
    }

    fun playPause() {
        callService("playPause") { it.playPause() }
    }

    fun seek(pos: Int) {
        callService("seek") { it.seek(pos) }
    }

    fun toggleLoop() {
        callService("toggleLoop") { it.toggleLoop() }
    }

    fun toggleShuffle() {
        callService("toggleShuffle") { it.toggleShuffle() }
    }

    /** Called on main after startRoon; retains the latest hardware state across endpoint recovery. */
    fun reportVolumeState(volume: Double, muted: Boolean) {
        if (userInitiatedUnbind || activeStartParams == null) return
        latestVolumeReport = volume to muted
        if (bound && networkAvailable != false && pendingStartParams == null) {
            callService("reportVolumeState") { it.reportVolumeState(volume, muted) }
        }
    }

    fun isServiceRunning(): Boolean {
        return service?.asBinder()?.isBinderAlive == true
    }

    private fun bindService() = runCatching {
        if (bound || binding) return@runCatching
        val ctx = contextReference.get()
        if (ctx == null) {
            Timber.e("bindService: context is null, cannot bind")
            return@runCatching
        }
        binding = true
        roonServiceIntent = Intent(ctx, RoonService::class.java)
        // 先 startService 让服务存活，再 bindService 绑定
        ctx.startService(roonServiceIntent)
        val result = roonServiceIntent?.let {
            ctx.bindService(it, connection, Context.BIND_AUTO_CREATE)
        } == true
        if (!result) {
            binding = false
            scheduleRebind()
        }
        // bindService 返回 true 仅代表绑定请求被接受，服务可用要等 onServiceConnected；
        // 故 bound 在 onServiceConnected 里置位，而非此处。
        Timber.d("bindService request accepted: $result (service will be usable after onServiceConnected)")
    }.onFailure {
        Timber.e(it, "Failed to bind RoonService")
        bound = false
        binding = false
        scheduleRebind()
    }

    private fun registerNetworkCallback(context: Context) {
        if (networkCallback != null) return
        val manager = context.getSystemService(ConnectivityManager::class.java) ?: return
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                mainHandler.post {
                    if (networkCallback === this) handleNetworkLost(network.networkHandle)
                }
            }

            override fun onAvailable(network: Network) {
                mainHandler.post {
                    if (networkCallback === this) handleNetworkAvailable(network.networkHandle)
                }
            }
        }
        runCatching {
            defaultNetworkHandle = manager.activeNetwork?.networkHandle
            networkAvailable = defaultNetworkHandle != null
            networkCallback = callback
            manager.registerDefaultNetworkCallback(callback)
            connectivityManager = manager
            registerInterfaceCallback(manager)
        }.onFailure {
            networkCallback = null
            networkAvailable = null
            defaultNetworkHandle = null
            Timber.w(it, "Failed to register Roon network callback")
        }
    }

    /** The SDK advertises every LAN interface, including a former default that is lingering. */
    private fun registerInterfaceCallback(manager: ConnectivityManager) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                mainHandler.post {
                    if (interfaceCallback === this) interfaceNetworks.add(network.networkHandle)
                }
            }
            override fun onLinkPropertiesChanged(network: Network, properties: LinkProperties) {
                val name = properties.interfaceName ?: return
                val addresses = roonLanIpv4Addresses(name,
                    properties.linkAddresses.map { it.address to it.prefixLength })
                mainHandler.post {
                    if (interfaceCallback === this) handleInterfaceAddresses(network.networkHandle, addresses)
                }
            }
            override fun onLost(network: Network) {
                mainHandler.post {
                    if (interfaceCallback === this) handleInterfaceLost(network.networkHandle)
                }
            }
        }
        interfaceCallback = callback
        initialTopologySettling = true
        val settle = Runnable {
            if (interfaceCallback === callback) finishInitialTopologyObservation()
        }
        initialTopologySettler = settle
        runCatching {
            manager.registerNetworkCallback(
                NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET)
                    .build(), callback,
            )
            mainHandler.postDelayed(settle, NETWORK_SETTLE_MS)
        }.onFailure {
            interfaceCallback = null
            initialTopologySettling = false
            initialTopologySettler = null
            Timber.w(it, "Failed to observe Roon LAN interface retirement")
        }
    }

    /** Tracks usable addresses after onAvailable; IPv6 and DNS-only changes leave this set unchanged. */
    private fun handleInterfaceAddresses(networkHandle: Long, addresses: Set<String>) {
        if (userInitiatedUnbind || networkHandle !in interfaceNetworks) return
        val changed = lanTopology.snapshot()[networkHandle].orEmpty() != addresses
        if (lanTopology.update(networkHandle, addresses)) {
            retireNetworkEndpoint("LAN IPv4 addresses changed")
        }
        if (changed) initialTopologySettler?.let { settle ->
            mainHandler.removeCallbacks(settle)
            mainHandler.postDelayed(settle, NETWORK_SETTLE_MS)
        }
    }

    /** Starts only after initial callback addresses settle, without synchronous Binder enumeration. */
    private fun finishInitialTopologyObservation() {
        initialTopologySettling = false
        initialTopologySettler = null
        networkRecoveryRunnable.run()
    }

    /** An obsolete advertised interface can still own a live RAAT session's audio sockets. */
    private fun handleInterfaceLost(networkHandle: Long) {
        if (userInitiatedUnbind || !interfaceNetworks.remove(networkHandle)) return
        if (lanTopology.remove(networkHandle)) retireNetworkEndpoint("LAN interface removed")
    }

    /** A new default network cannot reuse sockets belonging to the previous RAAT endpoint. */
    private fun handleNetworkAvailable(networkHandle: Long) {
        if (userInitiatedUnbind) return
        val wasUnavailable = networkAvailable == false
        defaultNetworkHandle = networkHandle
        networkAvailable = true
        if (endpointNetworkHandle?.let { it != networkHandle } == true) retireNetworkEndpoint("default network replaced")
        if (wasUnavailable) pendingStartParams = activeStartParams
        if (pendingStartParams == null || retiringService != null) return
        if (service == null || !bound) {
            bindService()
        } else {
            mainHandler.removeCallbacks(networkRecoveryRunnable)
            mainHandler.postDelayed(networkRecoveryRunnable, NETWORK_SETTLE_MS)
        }
    }

    /** Ignores an obsolete network's delayed loss after a replacement became available. */
    private fun handleNetworkLost(networkHandle: Long) {
        if (userInitiatedUnbind || defaultNetworkHandle != networkHandle) return
        defaultNetworkHandle = null
        networkAvailable = false
        mainHandler.removeCallbacks(networkRecoveryRunnable)
        pendingStartParams = activeStartParams
        retireNetworkEndpoint("default network lost")
    }

    /** Waits for binder death before starting the pending endpoint on its latest network. */
    private fun retireNetworkEndpoint(reason: String) {
        val currentService = service ?: return
        if (activeStartParams == null || retiringService === currentService) return
        pendingStartParams = activeStartParams
        retiringService = currentService
        synchronized(outputSelectionLock) { outputSelectionVersion++ }
        mainHandler.removeCallbacks(networkRecoveryRunnable)
        callService("retire endpoint after network change") { it.stopRoon() }
        Timber.i("Roon network topology changed (%s); retiring endpoint before reconnecting", reason)
    }

    private fun unregisterNetworkCallback() {
        val manager = connectivityManager
        val callback = networkCallback
        if (manager != null && callback != null) {
            runCatching { manager.unregisterNetworkCallback(callback) }
                .onFailure { Timber.w(it, "Failed to unregister Roon network callback") }
        }
        interfaceCallback?.let { observer ->
            runCatching { manager?.unregisterNetworkCallback(observer) }
                .onFailure { Timber.w(it, "Failed to unregister Roon interface callback") }
        }
        interfaceCallback = null
        initialTopologySettler?.let(mainHandler::removeCallbacks)
        initialTopologySettler = null
        initialTopologySettling = false
        interfaceNetworks.clear()
        lanTopology.clear()
        connectivityManager = null
        networkCallback = null
        networkAvailable = null
        defaultNetworkHandle = null
    }

    private inline fun callService(action: String, call: (IRoonService) -> Unit): Boolean {
        val currentService = service ?: return false
        return runCatching { call(currentService) }
            .fold(
                onSuccess = { true },
                onFailure = { error ->
                    Timber.w(error, "Roon service call failed: $action")
                    if (error is RemoteException || !currentService.asBinder().isBinderAlive) {
                        mainHandler.post {
                            if (service === currentService) {
                                recoverServiceConnection("dead binder during $action")
                            }
                        }
                    }
                    false
                }
            )
    }

    private fun recoverServiceConnection(reason: String) {
        mainHandler.removeCallbacks(networkRecoveryRunnable)
        service = null
        retiringService = null
        sourceStateAppliedTo = null
        endpointNetworkHandle = null
        lanTopology.endpointStopped()
        synchronized(outputSelectionLock) { outputSelectionVersion++ }
        bound = false
        binding = false
        pendingStartParams = activeStartParams
        if (::contextReference.isInitialized) {
            runCatching { contextReference.get()?.unbindService(connection) }
                .onFailure { Timber.w(it, "Failed to clear Roon service binding after $reason") }
        }
        if (!userInitiatedUnbind) {
            Timber.w("Roon service unavailable ($reason); scheduling rebind")
            scheduleRebind()
        }
    }

    private fun scheduleRebind() {
        mainHandler.removeCallbacks(rebindRunnable)
        mainHandler.postDelayed(rebindRunnable, 1000)
    }
}

/** Stable IPv4-only LAN identity; DNS, address ordering and temporary IPv6 addresses are irrelevant. */
internal fun roonLanIpv4Addresses(
    interfaceName: String,
    addresses: List<Pair<InetAddress, Int>>,
): Set<String> = addresses.mapNotNull { (address, prefix) ->
    if (address !is Inet4Address || address.isAnyLocalAddress || address.isLoopbackAddress ||
        address.isLinkLocalAddress || address.isMulticastAddress || prefix !in 0..32) null
    else "$interfaceName:${address.hostAddress}/$prefix"
}.toSet()
