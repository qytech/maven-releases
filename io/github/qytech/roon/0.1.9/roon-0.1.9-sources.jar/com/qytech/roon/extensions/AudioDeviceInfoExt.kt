package com.qytech.roon.extensions

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import androidx.annotation.WorkerThread
import com.qytech.audioplayer.utils.SystemPropUtil
import com.qytech.roon.model.SupportedFormat

private val preferredOutputTypes = setOf(
    AudioDeviceInfo.TYPE_USB_DEVICE,
    AudioDeviceInfo.TYPE_USB_HEADSET,
    AudioDeviceInfo.TYPE_HDMI,
    AudioDeviceInfo.TYPE_LINE_ANALOG,
    AudioDeviceInfo.TYPE_LINE_DIGITAL,
    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
    AudioDeviceInfo.TYPE_BUILTIN_SPEAKER,
)

/**
 * Returns the best currently exposed output device using public Android APIs.
 *
 * Android's product strategy APIs are hidden for normal apps on this build target, so the Roon
 * driver falls back to the output device list and prefers externally routed audio devices first.
 */
fun Context.getCurrentOutputDevice(): AudioDeviceInfo? = runCatching {
    val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val outputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
    preferredOutputTypes
        .asSequence()
        .mapNotNull { preferredType -> outputDevices.firstOrNull { it.type == preferredType } }
        .firstOrNull()
        ?: outputDevices.firstOrNull()
}.getOrNull()

private val dsdCarrierRates = intArrayOf(88200, 176400, 352800, 705600, 1411200)
private val pcmCandidateRates = intArrayOf(
    44100, 48000, 88200, 96000, 176400, 192000, 352800, 384000, 705600, 768000,
)

/**
 * Queries the current MEDIA/MUSIC route and advertises only formats its actual Android sink accepts.
 * The caller must run this Binder-backed query on a worker after output routing has settled.
 */
@WorkerThread
fun Context.getSupportedRoonFormats(outputDevice: AudioDeviceInfo?): List<SupportedFormat> {
    val attributes = roonAudioAttributes()
    val i2s = SystemPropUtil.getBoolean("persist.sys.audio.i2s", false)
    val directSupport = { encoding: Int, rate: Int, mask: Int ->
        isRoonDirectPlaybackSupported(encoding, rate, mask, attributes)
    }
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
        return outputDevice?.mapDeviceProfiles(i2s, directSupport).orEmpty()
    }
    val manager = getSystemService(AudioManager::class.java)
    val profiles = manager.getDirectProfilesForAttributes(attributes)
    if (profiles.isNotEmpty()) {
        return profiles.flatMap {
            mapRoonAudioProfile(it.format, it.sampleRates, it.channelMasks, i2s, directSupport)
        }.distinct()
    }
    // API 33 queries follow the media route; every fallback candidate still needs positive support.
    val pcm = intArrayOf(
        AudioFormat.ENCODING_PCM_16BIT, AudioFormat.ENCODING_PCM_32BIT,
    ).flatMap { encoding ->
        mapRoonAudioProfile(encoding, pcmCandidateRates,
            intArrayOf(AudioFormat.CHANNEL_OUT_MONO, AudioFormat.CHANNEL_OUT_STEREO), i2s, directSupport)
    }
    val dsdMask = if (i2s) AudioFormat.CHANNEL_OUT_QUAD else AudioFormat.CHANNEL_OUT_STEREO
    return (pcm + mapRoonAudioProfile(
        AudioFormat.ENCODING_DSD, dsdCarrierRates, intArrayOf(dsdMask), i2s, directSupport,
    )).distinct()
}

/** Preserves the device extension ABI while restricting candidates to this device's capabilities. */
@WorkerThread
fun AudioDeviceInfo.getSupportedFormats(): List<SupportedFormat> {
    val attributes = roonAudioAttributes()
    return mapDeviceProfiles(SystemPropUtil.getBoolean("persist.sys.audio.i2s", false)) { encoding, rate, mask ->
        isRoonDirectPlaybackSupported(encoding, rate, mask, attributes)
    }
}

private fun AudioDeviceInfo.mapDeviceProfiles(
    i2s: Boolean,
    directSupport: (Int, Int, Int) -> Boolean,
): List<SupportedFormat> {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && audioProfiles.isNotEmpty()) {
        return audioProfiles.flatMap {
            mapRoonAudioProfile(it.format, it.sampleRates, it.channelMasks, i2s, directSupport)
        }.distinct()
    }
    // Pre-33 direct support can describe another available route, so never invent device candidates.
    return encodings.flatMap {
        mapRoonAudioProfile(it, sampleRates, channelMasks, i2s, directSupport)
    }.distinct()
}

private fun roonAudioAttributes(): AudioAttributes = AudioAttributes.Builder()
    .setUsage(AudioAttributes.USAGE_MEDIA)
    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
    .build()

@Suppress("DEPRECATION")
private fun isRoonDirectPlaybackSupported(
    encoding: Int,
    rate: Int,
    mask: Int,
    attributes: AudioAttributes,
): Boolean = runCatching {
    val format = AudioFormat.Builder().setEncoding(encoding).setSampleRate(rate).setChannelMask(mask).build()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        supportsRoonDirectPlayback(AudioManager.getDirectPlaybackSupport(format, attributes))
    } else {
        AudioTrack.isDirectPlaybackSupported(format, attributes)
    }
}.getOrDefault(false)

/** RoonApp builds a normal AudioTrack and cannot use formats available only through offload. */
internal fun supportsRoonDirectPlayback(support: Int): Boolean =
    support and AudioManager.DIRECT_PLAYBACK_BITSTREAM_SUPPORTED != 0

/** Maps source formats only after checking the encoding, carrier rate and mask used by RoonApp. */
internal fun mapRoonAudioProfile(
    encoding: Int,
    sampleRates: IntArray,
    channelMasks: IntArray,
    i2sFourChannel: Boolean,
    isDirectSupported: (encoding: Int, sampleRate: Int, channelMask: Int) -> Boolean,
): List<SupportedFormat> {
    if (encoding == AudioFormat.ENCODING_DSD) {
        val mask = if (i2sFourChannel) AudioFormat.CHANNEL_OUT_QUAD else AudioFormat.CHANNEL_OUT_STEREO
        if (mask !in channelMasks) return emptyList()
        return sampleRates.distinct()
            .filter { it in dsdCarrierRates && isDirectSupported(encoding, it, mask) }
            .map { SupportedFormat("DSD", it * 32, 2, 1) }
    }
    // PCM8 needs unsigned sample/silence conversion that the current write path does not perform.
    val bitDepths = when (encoding) {
        AudioFormat.ENCODING_PCM_16BIT -> listOf(16)
        AudioFormat.ENCODING_PCM_24BIT_PACKED -> listOf(24)
        AudioFormat.ENCODING_PCM_32BIT -> listOf(24, 32)
        else -> return emptyList()
    }
    // Native expands packed source PCM24 into an integer PCM32 AudioTrack container.
    val sinkEncoding = if (encoding == AudioFormat.ENCODING_PCM_24BIT_PACKED) {
        AudioFormat.ENCODING_PCM_32BIT
    } else encoding
    return sampleRates.distinct().filter { it > 0 }.flatMap { rate ->
        channelMasks.distinct().filter {
            (it == AudioFormat.CHANNEL_OUT_MONO || it == AudioFormat.CHANNEL_OUT_STEREO) &&
                isDirectSupported(sinkEncoding, rate, it)
        }.flatMap { mask ->
            bitDepths.map { bits ->
                SupportedFormat("PCM", rate, if (mask == AudioFormat.CHANNEL_OUT_MONO) 1 else 2, bits)
            }
        }
    }
}

fun AudioDeviceInfo.getRoonSignalPathMethod(): String = when (type) {
    AudioDeviceInfo.TYPE_USB_DEVICE,
    AudioDeviceInfo.TYPE_USB_HEADSET,
    -> "usb"

    AudioDeviceInfo.TYPE_HDMI,
    AudioDeviceInfo.TYPE_LINE_DIGITAL,
    -> "digital"

    else -> "analog"
}
