package com.qytech.roon.model

import android.os.Parcelable
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * @author Jax
 * @date 2025/06/19
 * @constructor 创建[RoonMetadata]
 * @param [isSeekAllowed]
 * @param [nowPlaying]
 * @param [isNextAllowed]
 * @param [seek]
 * @param [isPreviousAllowed]
 * @param [isPauseAllowed]
 * @param [loop]
 * @param [isPlayAllowed]
 * @param [streamFormat]
 * @param [shuffle]
 * @param [state]
 */
@Parcelize
data class RoonMetadata(
    @SerializedName("is_seek_allowed") val isSeekAllowed: Boolean,
    @SerializedName("now_playing") val nowPlaying: NowPlaying? = null,
    @SerializedName("is_next_allowed") val isNextAllowed: Boolean,
    val seek: Int,
    @SerializedName("is_previous_allowed") val isPreviousAllowed: Boolean,
    @SerializedName("is_pause_allowed") val isPauseAllowed: Boolean,
    val loop: String,
    @SerializedName("is_play_allowed") val isPlayAllowed: Boolean,
    @SerializedName("stream_format") val streamFormat: StreamFormat? = null,
    val shuffle: Boolean,
    val state: String,
) : Parcelable {
    companion object {
        fun fromJson(json: String): RoonMetadata {
            return Gson().fromJson(json, RoonMetadata::class.java)
        }
    }
}

@Parcelize
data class NowPlaying(
    val composer: String? = null,
    @SerializedName("artwork_url") val artworkUrl: String? = null,
    @SerializedName("one_line") val oneLine: String? = null,
    val artist: String? = null,
    @SerializedName("two_line_subtitle") val twoLineSubtitle: String? = null,
    val length: Int? = null,
    @SerializedName("three_line_subsubtitle") val threeLineSubsubtitle: String? = null,
    @SerializedName("two_line_title") val twoLineTitle: String? = null,
    @SerializedName("three_line_subtitle") val threeLineSubtitle: String? = null,
    @SerializedName("three_line_title") val threeLineTitle: String? = null,
    val album: String? = null,
    val title: String? = null,
) : Parcelable {
    /** Selects the richest RAAT display title, with deprecated metadata as a compatibility fallback. */
    val displayTitle: String?
        get() = firstNonBlank(threeLineTitle, twoLineTitle, oneLine, title)

    /** Selects the richest RAAT display artist, with deprecated metadata as a compatibility fallback. */
    val displayArtist: String?
        get() = firstNonBlank(threeLineSubtitle, twoLineSubtitle, artist)

    /** Selects the RAAT three-line album, with deprecated metadata as a compatibility fallback. */
    val displayAlbum: String?
        get() = firstNonBlank(threeLineSubsubtitle, album)
}

private fun firstNonBlank(vararg values: String?): String? =
    values.firstOrNull { !it.isNullOrBlank() }

@Parcelize
data class StreamFormat(
    @SerializedName("sample_type") val sampleType: String = "",
    @SerializedName("sample_rate") val sampleRate: Int = 0,
    val channels: Int = 0,
    @SerializedName("bits_per_sample") val bitsPerSample: Int = 0,
    val sampleSubtype: String = "",
) : Parcelable {
    fun isDsd(): Boolean {
        return sampleType.lowercase() == "dsd"
    }
}
