package com.qytech.roon.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * @author Administrator
 * @date 2025/6/13 16:34
 */
@Parcelize
enum class RoonPlayState : Parcelable {
    UNKNOWN,
    PLAYING,
    PAUSED,
    STOPPED;

    companion object {
        fun fromInt(state: Int): RoonPlayState {
            return when (state) {
                1 -> PLAYING
                2 -> PAUSED
                3 -> STOPPED
                else -> UNKNOWN
            }
        }
    }

    fun toInt(): Int {
        return when (this) {
            PLAYING -> 1
            PAUSED -> 2
            STOPPED -> 3
            UNKNOWN -> 0
        }
    }
}