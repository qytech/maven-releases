package com.qytech.roon.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class SignalPath(
    val quality: String,
    val type: String,
    val method: String,
) : Parcelable