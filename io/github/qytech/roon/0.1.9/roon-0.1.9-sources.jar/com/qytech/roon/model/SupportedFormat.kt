package com.qytech.roon.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * @author Administrator
 * @date 2025/6/13 17:15
 */
@Parcelize
data class SupportedFormat(
    val sampleType: String,
    val sampleRate: Int,
    val channels: Int,
    val bitsPerSample: Int,
) : Parcelable