package com.qytech.roon.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * @author Administrator
 * @date 2025/6/3 18:41
 */
@Parcelize
data class VolumeState(
    val volumeType: Int,
    val minVolume: Double,
    val maxVolume: Double,
    val volume: Double,
    val muted: Boolean,
    val volumeStep: Double,
    val dbMinVolume: Double,
    val dbMaxVolume: Double,
) : Parcelable